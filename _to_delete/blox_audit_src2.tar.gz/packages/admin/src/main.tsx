import { Navigate, Route, Routes } from 'react-router-dom';
import {
  AuthGuard,
  LoginPage,
  ForgotPasswordPage,
  ResetPasswordPage,
  TwoFactorLoginPage,
  MfaSetupPage,
  BloxShell,
  mountPortalApp,
  type BloxNavItem,
} from '@drivemarket/shared';
import '@drivemarket/shared/styles/global.scss';
import { DashboardPage } from './pages/DashboardPage';
import { ApplicationsPage } from './pages/ApplicationsPage';
import { ProductsPage } from './pages/ProductsPage';
import { OffersPage } from './pages/EntityListPages';
import { LedgersPage } from './pages/LedgersPage';

const nav: BloxNavItem[] = [
  { to: '/main/dashboard', label: 'Dashboard', icon: 'home' },
  { to: '/main/applications', label: 'Applications', icon: 'apps' },
  { to: '/main/products', label: 'Products', icon: 'products' },
  { to: '/main/offers', label: 'Offers', icon: 'offers' },
  { to: '/main/ledgers', label: 'Installments', icon: 'ledgers' },
];

function App() {
  return (
    <Routes>
      <Route
        path="/auth/login"
        element={<LoginPage portalLabel="Blox Admin" homePath="/main/dashboard" />}
      />
      <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/auth/reset-password" element={<ResetPasswordPage />} />
      <Route
        path="/auth/two-factor"
        element={<TwoFactorLoginPage portalLabel="Blox Admin" homePath="/main/dashboard" />}
      />
      <Route
        path="/auth/mfa-setup"
        element={<MfaSetupPage portalLabel="Blox Admin" homePath="/main/dashboard" />}
      />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="admin" reasonParam="not_admin">
            <BloxShell title="Admin" nav={nav} homePaths={['/main/dashboard']}>
              <Routes>
                <Route path="/" element={<Navigate to="/main/dashboard" replace />} />
                <Route path="/main/dashboard" element={<DashboardPage />} />
                <Route path="/main/applications" element={<ApplicationsPage />} />
                <Route path="/main/products" element={<ProductsPage />} />
                <Route path="/main/offers" element={<OffersPage />} />
                <Route path="/main/ledgers" element={<LedgersPage />} />
                <Route path="*" element={<Navigate to="/main/dashboard" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

mountPortalApp({ sentryApp: 'admin', authBootstrap: true, root: <App /> });
