import { useEffect, useState } from 'react';
import { Navigate, Route, Routes, Link, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  AuthGuard,
  LoginPage,
  ForgotPasswordPage,
  ResetPasswordPage,
  TwoFactorLoginPage,
  MfaSetupPage,
  BloxShell,
  apiFetch,
  buildPaginationQuery,
  paginationWindow,
  getApiBase,
  applicationOpsPillVariant,
  applicationStatusLabel,
  mountPortalApp,
} from '@drivemarket/shared';
import '@drivemarket/shared/styles/global.scss';

const nav = [
  { to: '/', label: 'Queue', icon: 'queue' as const },
  { to: '/applications', label: 'Applications', icon: 'apps' as const },
  { to: '/zoho-failures', label: 'Zoho failures', icon: 'logs' as const },
];

type AppDetail = {
  id: string;
  status: string;
  customerSnapshot?: Record<string, unknown>;
  pricingSnapshot?: Record<string, unknown>;
  rejectionReason?: string | null;
  resubmissionComment?: string | null;
  product?: { make: string; model: string; modelYear?: number };
  company?: { name: string };
  customer?: { name: string; email: string; phone?: string | null };
  offer?: { name: string; annualRentRate?: number | string };
  documents?: Array<{ id: string; category: string; createdAt: string }>;
};

function snapshotText(value: unknown): string {
  if (value == null || value === '') return '—';
  return String(value);
}

function snapshotMoney(value: unknown): string {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '—';
  return `QAR ${amount.toLocaleString()}`;
}

function snapshotPercent(value: unknown): string {
  const rate = Number(value);
  if (!Number.isFinite(rate)) return '—';
  return `${rate}%`;
}

function snapshotTenure(pricing: Record<string, unknown>): string {
  const months = Number(pricing.tenor ?? pricing.tenure);
  if (!Number.isFinite(months) || months <= 0) return '—';
  return `${months} months`;
}

function ApplicantPlanSection({ data }: { data: AppDetail }) {
  const customer = data.customerSnapshot ?? {};
  const pricing = data.pricingSnapshot ?? {};
  const rowStyle = { display: 'grid', gridTemplateColumns: '9rem 1fr', gap: 8, fontSize: '0.875rem' } as const;
  const labelStyle = { color: 'var(--blox-muted, #5b6b73)', fontWeight: 600 } as const;

  return (
    <section className="blox-panel">
      <h2 className="blox-panel__title">Applicant &amp; plan</h2>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '20px 32px',
        }}
      >
        <div>
          <h3 style={{ margin: '0 0 10px', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.75 }}>
            Applicant
          </h3>
          <div style={{ display: 'grid', gap: 8 }}>
            <div style={rowStyle}>
              <span style={labelStyle}>Full name</span>
              <span>{snapshotText(customer.full_name ?? data.customer?.name)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Phone</span>
              <span>{snapshotText(customer.phone ?? data.customer?.phone)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>QID</span>
              <span>{snapshotText(customer.qid)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Employment</span>
              <span>{snapshotText(customer.employment)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Stated income</span>
              <span>{snapshotMoney(customer.income)}</span>
            </div>
          </div>
        </div>
        <div>
          <h3 style={{ margin: '0 0 10px', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.75 }}>
            Plan terms
          </h3>
          <div style={{ display: 'grid', gap: 8 }}>
            <div style={rowStyle}>
              <span style={labelStyle}>Vehicle price</span>
              <span>{snapshotMoney(pricing.list_price)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Offer</span>
              <span>{snapshotText(data.offer?.name)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Annual rate</span>
              <span>{snapshotPercent(pricing.rate ?? data.offer?.annualRentRate)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Tenure</span>
              <span>{snapshotTenure(pricing)}</span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Down payment</span>
              <span>
                {snapshotMoney(pricing.down_payment)}
                {Number.isFinite(Number(pricing.down_payment_pct))
                  ? ` (${Number(pricing.down_payment_pct)}%)`
                  : ''}
              </span>
            </div>
            <div style={rowStyle}>
              <span style={labelStyle}>Monthly installment</span>
              <span className="blox-money">{snapshotMoney(pricing.monthly)}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Queue() {
  const [page, setPage] = useState(0);
  const { data, error } = useQuery({
    queryKey: ['ops-apps', page],
    queryFn: () =>
      apiFetch<{
        total: number;
        items: Array<{
          id: string;
          status: string;
          customer: { name: string; email: string };
          product: { make: string; model: string };
          company: { name: string };
        }>;
      }>(`/api/ops/applications?${buildPaginationQuery(page)}`),
  });
  const items = data?.items ?? [];
  const { from, to, total } = paginationWindow(data?.total ?? 0, page);
  return (
    <div className="blox-page">
      <header className="blox-page-header">
        <div>
          <h1>Credit queue</h1>
          <p className="blox-page-header__subtitle">Applications awaiting underwriting review</p>
        </div>
      </header>
      {error && <p style={{ color: '#b42318' }}>{(error as Error).message}</p>}
      {!items.length ? (
        <p className="blox-empty">Queue clear.</p>
      ) : (
        <>
          <div className="blox-table-wrap">
            <table className="blox-table">
              <thead>
                <tr>
                  <th>Vehicle</th>
                  <th>Customer</th>
                  <th>Dealer</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {items.map((a) => (
                  <tr key={a.id}>
                    <td>
                      <Link to={`/applications/${a.id}`}>
                        {a.product.make} {a.product.model}
                      </Link>
                    </td>
                    <td>{a.customer.name}</td>
                    <td>{a.company.name}</td>
                    <td>
                      <span className={`blox-pill blox-pill--${applicationOpsPillVariant(a.status)}`}>{applicationStatusLabel(a.status)}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="blox-pagination" style={{ marginTop: 12 }}>
            <span>
              Showing {from}–{to} of {total}
            </span>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                type="button"
                className="blox-btn blox-btn--ghost"
                disabled={from <= 1}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
              >
                Previous
              </button>
              <button
                type="button"
                className="blox-btn blox-btn--ghost"
                disabled={to >= total}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Detail() {
  const { id } = useParams();
  const qc = useQueryClient();
  const [reason, setReason] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);
  const { data } = useQuery({
    queryKey: ['app', id],
    queryFn: () => apiFetch<AppDetail>(`/api/applications/${id}`),
    enabled: !!id,
  });

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ['app', id] });
    void qc.invalidateQueries({ queryKey: ['ops-apps'] });
  };

  const transition = useMutation({
    mutationFn: (toStatus: string) =>
      apiFetch(`/api/ops/applications/${id}/transition`, {
        method: 'POST',
        body: JSON.stringify({ toStatus, reason: reason.trim() || undefined }),
      }),
    onSuccess: invalidate,
    onError: (e: Error) => setActionError(e.message),
  });

  const approveContract = useMutation({
    mutationFn: () =>
      apiFetch(`/api/ops/applications/${id}/approve-contract`, { method: 'POST' }),
    onSuccess: invalidate,
    onError: (e: Error) => setActionError(e.message),
  });

  const activate = useMutation({
    mutationFn: (direct?: boolean) =>
      apiFetch(`/api/ops/applications/${id}/activate`, {
        method: 'POST',
        body: JSON.stringify({ direct: !!direct }),
      }),
    onSuccess: invalidate,
    onError: (e: Error) => setActionError(e.message),
  });

  const status = data?.status ?? '';
  const busy = transition.isPending || approveContract.isPending || activate.isPending;
  const detailLabel = data
    ? `${data.product?.make} ${data.product?.model} · ${data.customer?.name}`
    : '';

  return (
    <div className="blox-page">
      <header className="blox-page-header">
        <div>
          <h1>Application review</h1>
          <p className="blox-page-header__subtitle">
            {data?.product?.make} {data?.product?.model} · {data?.customer?.name}
          </p>
        </div>
        <div className="blox-page-header__actions">
          <Link className="blox-btn blox-btn--ghost" to="/">
            Back to queue
          </Link>
        </div>
      </header>

      {data && (
        <>
          <section className="blox-panel">
            <h2 className="blox-panel__title">Summary</h2>
            <p>
              Status: <span className={`blox-pill blox-pill--${applicationOpsPillVariant(status)}`}>{applicationStatusLabel(status)}</span>
            </p>
            <p>Dealer: {data.company?.name}</p>
            <p>Customer email: {data.customer?.email}</p>
          </section>

          <ApplicantPlanSection data={data} />

          {(data.documents?.length ?? 0) > 0 && (
            <section className="blox-panel">
              <h2 className="blox-panel__title">KYC documents</h2>
              <ul>
                {data.documents!.map((doc) => (
                  <li key={doc.id}>
                    {doc.category}{' '}
                    <a
                      href={`${getApiBase()}/api/applications/${id}/documents/${doc.id}/file`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      View
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section className="blox-panel" style={{ maxWidth: 560 }}>
            <h2 className="blox-panel__title">Actions</h2>
            {actionError && <p style={{ color: '#b42318' }}>{actionError}</p>}
            <label style={{ display: 'grid', gap: 6, fontSize: '0.875rem', fontWeight: 600 }}>
              Reason (required for reject / resubmission)
              <input value={reason} onChange={(e) => setReason(e.target.value)} />
            </label>
            <div style={{ display: 'flex', gap: 12, marginTop: 16, flexWrap: 'wrap' }}>
              {status === 'under_review' && (
                <button
                  type="button"
                  className="blox-btn blox-btn--primary"
                  disabled={busy}
                  onClick={() => approveContract.mutate()}
                >
                  {approveContract.isPending ? 'Sending…' : 'Approve & send contract'}
                </button>
              )}
              {status === 'contracts_submitted' && (
                <button
                  type="button"
                  className="blox-btn blox-btn--secondary"
                  disabled={busy}
                  onClick={() => transition.mutate('contract_under_review')}
                >
                  Start contract review
                </button>
              )}
              {status === 'contract_under_review' && (
                <>
                  <button
                    type="button"
                    className="blox-btn blox-btn--secondary"
                    disabled={busy}
                    onClick={() => transition.mutate('pending_finance_activation')}
                  >
                    Approve contract
                  </button>
                  <button
                    type="button"
                    className="blox-btn blox-btn--ghost"
                    disabled={busy}
                    onClick={() => transition.mutate('down_payment_required')}
                  >
                    Require down payment
                  </button>
                </>
              )}
              {status === 'pending_finance_activation' && (
                <button
                  type="button"
                  className="blox-btn blox-btn--primary"
                  disabled={busy}
                  onClick={() => {
                    if (
                      !window.confirm(
                        `Activate financing for ${detailLabel}? This will start the repayment schedule.`,
                      )
                    ) {
                      return;
                    }
                    activate.mutate(false);
                  }}
                >
                  {activate.isPending ? 'Activating…' : 'Activate financing'}
                </button>
              )}
              {status === 'under_review' && (
                <button
                  type="button"
                  className="blox-btn blox-btn--ghost"
                  disabled={busy}
                  onClick={() => {
                    if (
                      !window.confirm(
                        `Direct activate financing for ${detailLabel}? This skips normal approval steps.`,
                      )
                    ) {
                      return;
                    }
                    activate.mutate(true);
                  }}
                >
                  {activate.isPending ? 'Activating…' : 'Direct activate'}
                </button>
              )}
              {['under_review', 'resubmission_required', 'contract_signing_required'].includes(status) && (
                <>
                  <button
                    type="button"
                    className="blox-btn blox-btn--secondary"
                    disabled={busy}
                    onClick={() => transition.mutate('resubmission_required')}
                  >
                    Request resubmission
                  </button>
                  <button
                    type="button"
                    className="blox-btn blox-btn--danger"
                    disabled={busy}
                    onClick={() => {
                      if (!window.confirm(`Reject application for ${detailLabel}?`)) return;
                      transition.mutate('rejected');
                    }}
                  >
                    Reject
                  </button>
                </>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function ZohoFailuresPage() {
  const { data, error } = useQuery({
    queryKey: ['zoho-failures'],
    queryFn: () =>
      apiFetch<
        Array<{
          application_id: string;
          reason: string;
          status: string;
          customer_email: string;
          error: string | null;
        }>
      >('/api/ops/zoho/failures'),
  });

  return (
    <div className="blox-page">
      <header className="blox-page-header">
        <div>
          <h1>Zoho sync failures</h1>
          <p className="blox-page-header__subtitle">Applications that failed CRM export</p>
        </div>
      </header>
      {error && <p style={{ color: '#b42318' }}>{(error as Error).message}</p>}
      {!data?.length ? (
        <p className="blox-empty">No CRM failures.</p>
      ) : (
        <div className="blox-table-wrap">
          <table className="blox-table">
            <thead>
              <tr>
                <th>Application</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Error</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr key={row.application_id}>
                  <td>
                    <Link to={`/applications/${row.application_id}`}>{row.application_id.slice(0, 8)}…</Link>
                  </td>
                  <td>{row.customer_email}</td>
                  <td>{row.status}</td>
                  <td>{row.error ?? row.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/auth/login" element={<LoginPage portalLabel="Blox Credit" homePath="/" />} />
      <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/auth/reset-password" element={<ResetPasswordPage />} />
      <Route
        path="/auth/two-factor"
        element={<TwoFactorLoginPage portalLabel="Blox Credit" homePath="/" />}
      />
      <Route path="/auth/mfa-setup" element={<MfaSetupPage portalLabel="Blox Credit" homePath="/" />} />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="credit_officer" reasonParam="not_credit">
            <BloxShell title="Credit" nav={nav}>
              <Routes>
                <Route path="/" element={<Queue />} />
                <Route path="/applications" element={<Queue />} />
                <Route path="/applications/:id" element={<Detail />} />
                <Route path="/zoho-failures" element={<ZohoFailuresPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

mountPortalApp({ sentryApp: 'credit', authBootstrap: true, root: <App /> });
