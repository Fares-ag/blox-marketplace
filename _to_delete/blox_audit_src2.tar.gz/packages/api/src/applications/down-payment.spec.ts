import { BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApplicationStatus, Prisma, UserRole } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';
import { ActivityService } from '../common/activity.service';
import { PrismaService } from '../prisma/prisma.service';
import { StorageService } from '../storage/storage.service';
import { ComplianceService } from '../compliance/compliance.service';
import { ApplicationsLifecycleService } from './applications-lifecycle.service';
import {
  assertDownPaymentSatisfied,
  requiredDownPaymentAmount,
  sumDownPaymentRecorded,
} from './down-payment';

describe('down-payment helpers', () => {
  it('reads required amount from pricingSnapshot.down_payment', () => {
    expect(
      requiredDownPaymentAmount({ list_price: 100_000, down_payment: 20_000 }).toFixed(2),
    ).toBe('20000.00');
  });

  it('derives required amount from list_price and down_payment_pct when down_payment missing', () => {
    expect(
      requiredDownPaymentAmount({ list_price: 100_000, down_payment_pct: 15 }).toFixed(2),
    ).toBe('15000.00');
  });

  it('throws down_payment_incomplete when recorded is below required', () => {
    expect(() =>
      assertDownPaymentSatisfied(new Prisma.Decimal(20_000), new Prisma.Decimal(19_999.99)),
    ).toThrow(BadRequestException);
    expect(() =>
      assertDownPaymentSatisfied(new Prisma.Decimal(20_000), new Prisma.Decimal(19_999.99)),
    ).toThrow('down_payment_incomplete');
  });

  it('passes when recorded meets or exceeds required', () => {
    expect(() =>
      assertDownPaymentSatisfied(new Prisma.Decimal(20_000), new Prisma.Decimal(20_000)),
    ).not.toThrow();
    expect(() =>
      assertDownPaymentSatisfied(new Prisma.Decimal(20_000), new Prisma.Decimal(25_000)),
    ).not.toThrow();
  });

  it('sums down_payment PaymentEvents', async () => {
    const db = {
      paymentEvent: {
        findMany: vi.fn().mockResolvedValue([
          { amount: new Prisma.Decimal(10_000) },
          { amount: new Prisma.Decimal(10_000) },
        ]),
      },
    };
    const total = await sumDownPaymentRecorded(db as never, 'app-1');
    expect(total.toFixed(2)).toBe('20000.00');
  });
});

describe('ApplicationsLifecycleService.activate down-payment guard', () => {
  const opsUser = {
    id: 'ops-1',
    role: UserRole.admin,
    companyId: 'co-1',
  } as never;

  function buildService(prisma: Partial<PrismaService>) {
    const config = { get: vi.fn().mockReturnValue(undefined) } as unknown as ConfigService;
    return new ApplicationsLifecycleService(
      prisma as PrismaService,
      { log: vi.fn(), notify: vi.fn() } as unknown as ActivityService,
      {} as StorageService,
      config,
      { assertPassedForApproval: vi.fn().mockResolvedValue(undefined) } as unknown as ComplianceService,
    );
  }

  const baseApp = {
    id: 'app-1',
    status: ApplicationStatus.pending_finance_activation,
    companyId: 'co-1',
    productId: 'prod-1',
    customerUserId: 'cust-1',
    pricingSnapshot: {
      list_price: 100_000,
      down_payment: 20_000,
      down_payment_pct: 20,
      monthly: 2500,
      tenor: 36,
    },
    paymentSchedules: [],
    company: { allowDirectActivate: false, separationOfDutiesEnabled: true },
  };

  function prismaWithSodMocks(extra: Partial<PrismaService>) {
    return {
      activityLog: { findMany: vi.fn().mockResolvedValue([]) },
      ...extra,
    };
  }

  it('throws down_payment_incomplete when no down_payment events exist', async () => {
    const prisma = prismaWithSodMocks({
      application: { findUnique: vi.fn().mockResolvedValue(baseApp) },
      paymentEvent: { findMany: vi.fn().mockResolvedValue([]) },
      $transaction: vi.fn().mockRejectedValue(new Error('transaction should not run')),
    });
    const service = buildService(prisma);

    await expect(service.activate(opsUser, 'app-1')).rejects.toMatchObject({
      message: 'down_payment_incomplete',
    });
  });

  it('throws down_payment_incomplete when recorded amount is insufficient', async () => {
    const prisma = prismaWithSodMocks({
      application: { findUnique: vi.fn().mockResolvedValue(baseApp) },
      paymentEvent: {
        findMany: vi.fn().mockResolvedValue([{ amount: new Prisma.Decimal(15_000) }]),
      },
      $transaction: vi.fn().mockRejectedValue(new Error('transaction should not run')),
    });
    const service = buildService(prisma);

    await expect(service.activate(opsUser, 'app-1')).rejects.toMatchObject({
      message: 'down_payment_incomplete',
    });
  });

  it('succeeds when down_payment events cover the required amount', async () => {
    const activated = { ...baseApp, status: ApplicationStatus.active };
    const prisma = prismaWithSodMocks({
      application: {
        findUnique: vi.fn().mockResolvedValue(baseApp),
      },
      paymentEvent: {
        findMany: vi.fn().mockResolvedValue([{ amount: new Prisma.Decimal(20_000) }]),
      },
      $transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) =>
        fn({
          paymentSchedule: { createMany: vi.fn() },
          application: {
            update: vi.fn().mockResolvedValue(activated),
          },
          product: { update: vi.fn() },
        }),
      ),
    });
    const service = buildService(prisma);

    const result = await service.activate(opsUser, 'app-1');
    expect(result.status).toBe(ApplicationStatus.active);
  });

  it('applies the down-payment check on direct activate too', async () => {
    const directApp = {
      ...baseApp,
      status: ApplicationStatus.under_review,
      company: { allowDirectActivate: true, separationOfDutiesEnabled: true },
    };
    const prisma = prismaWithSodMocks({
      application: { findUnique: vi.fn().mockResolvedValue(directApp) },
      paymentEvent: { findMany: vi.fn().mockResolvedValue([]) },
      $transaction: vi.fn().mockRejectedValue(new Error('transaction should not run')),
    });
    const service = buildService(prisma);

    await expect(service.activate(opsUser, 'app-1', { direct: true })).rejects.toMatchObject({
      message: 'down_payment_incomplete',
    });
  });
});
