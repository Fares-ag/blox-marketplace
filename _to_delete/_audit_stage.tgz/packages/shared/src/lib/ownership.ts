/**
 * Diminishing Musharakah ownership calculations (aligned with blox-badrGo).
 */

export interface OwnershipResult {
  customerOwnership: number;
  bloxOwnership: number;
  loanAmount: number;
  principalPerMonth: number;
}

export interface OwnershipScheduleInput {
  id?: string;
  sequence: number;
  dueDate: string;
  amount: string | number;
  status: string;
}

export interface OwnershipPricingInput {
  list_price?: unknown;
  price?: unknown;
  down_payment?: unknown;
  tenor?: unknown;
  tenure?: unknown;
}

export type OwnershipMilestoneKind =
  | 'first_payment'
  | 'quarter'
  | 'halfway'
  | 'three_quarters'
  | 'almost_there'
  | 'full_owner';

export interface OwnershipMilestone {
  date: string;
  ownershipPercentage: number;
  ownershipAmount: number;
  customerShare: number;
  bloxShare: number;
  paymentIndex: number;
  paymentStatus: 'paid' | 'upcoming' | 'missed';
  milestone?: OwnershipMilestoneKind;
  labelKey: string;
  sequence: number;
}

export interface OwnershipTimelineData {
  milestones: OwnershipMilestone[];
  currentOwnership: number;
  currentOwnershipAmount: number;
  bloxOwnership: number;
  vehiclePrice: number;
  downPayment: number;
  targetOwnership: number;
  progressPercentage: number;
  estimatedCompletionDate: string | null;
  totalPayments: number;
  completedPayments: number;
  projected: boolean;
  hasOverdue: boolean;
}

export function parseVehiclePrice(pricing: OwnershipPricingInput | null | undefined): number {
  const p = pricing ?? {};
  return Number(p.list_price ?? p.price ?? 0);
}

export function parseDownPayment(pricing: OwnershipPricingInput | null | undefined): number {
  const p = pricing ?? {};
  return Number(p.down_payment ?? 0);
}

export function parseTenureMonths(pricing: OwnershipPricingInput | null | undefined): number {
  const p = pricing ?? {};
  return Number(p.tenor ?? p.tenure ?? 0);
}

export function calculateOwnership(
  vehiclePrice: number,
  downPayment: number,
  tenureMonths: number,
  paymentIndex: number,
): OwnershipResult {
  const loanAmount = vehiclePrice - downPayment;
  const principalPerMonth = tenureMonths > 0 ? loanAmount / tenureMonths : 0;
  const calculatedCustomerOwnership = downPayment + principalPerMonth * (paymentIndex + 1);
  const customerOwnership = Math.min(calculatedCustomerOwnership, vehiclePrice);
  const bloxOwnership = Math.max(vehiclePrice - customerOwnership, 0);

  return { customerOwnership, bloxOwnership, loanAmount, principalPerMonth };
}

function paymentStatus(
  status: string,
  dueDate: string,
): 'paid' | 'upcoming' | 'missed' {
  if (status === 'paid') return 'paid';
  const due = new Date(dueDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  if (due < today) return 'missed';
  return 'upcoming';
}

function milestoneForPercentage(
  ownershipPercentage: number,
  index: number,
): { milestone?: OwnershipMilestoneKind; labelKey: string } {
  if (index === 0) {
    return { milestone: 'first_payment', labelKey: 'ownership.milestoneFirstPayment' };
  }
  if (ownershipPercentage >= 100) {
    return { milestone: 'full_owner', labelKey: 'ownership.milestone100' };
  }
  if (ownershipPercentage >= 95) {
    return { milestone: 'almost_there', labelKey: 'ownership.milestone95' };
  }
  if (ownershipPercentage >= 75 && ownershipPercentage < 95) {
    return { milestone: 'three_quarters', labelKey: 'ownership.milestone75' };
  }
  if (ownershipPercentage >= 50 && ownershipPercentage < 75) {
    return { milestone: 'halfway', labelKey: 'ownership.milestone50' };
  }
  if (ownershipPercentage >= 25 && ownershipPercentage < 50) {
    return { milestone: 'quarter', labelKey: 'ownership.milestone25' };
  }
  return { labelKey: 'ownership.paymentNumber' };
}

function addMonths(base: Date, months: number): Date {
  const d = new Date(base);
  d.setMonth(d.getMonth() + months);
  return d;
}

function buildProjectedSchedules(
  tenorMonths: number,
  monthlyAmount: number,
): OwnershipScheduleInput[] {
  if (tenorMonths <= 0) return [];
  const start = new Date();
  return Array.from({ length: tenorMonths }, (_, i) => ({
    sequence: i + 1,
    dueDate: addMonths(start, i + 1).toISOString(),
    amount: monthlyAmount,
    status: 'pending',
  }));
}

export function calculateOwnershipTimeline(
  pricingSnapshot: OwnershipPricingInput | null | undefined,
  paymentSchedules?: OwnershipScheduleInput[] | null,
): OwnershipTimelineData {
  const vehiclePrice = parseVehiclePrice(pricingSnapshot);
  const downPayment = parseDownPayment(pricingSnapshot);
  const tenorMonths = parseTenureMonths(pricingSnapshot);

  const schedules =
    paymentSchedules && paymentSchedules.length > 0
      ? [...paymentSchedules].sort((a, b) => a.sequence - b.sequence)
      : buildProjectedSchedules(
          tenorMonths,
          tenorMonths > 0 ? (vehiclePrice - downPayment) / tenorMonths : 0,
        );

  if (vehiclePrice <= 0 || schedules.length === 0) {
    const initialPct =
      vehiclePrice > 0 && downPayment > 0
        ? Math.round((downPayment / vehiclePrice) * 10000) / 100
        : 0;
    return {
      milestones: [],
      currentOwnership: initialPct,
      currentOwnershipAmount: downPayment,
      bloxOwnership: Math.max(vehiclePrice - downPayment, 0),
      vehiclePrice,
      downPayment,
      targetOwnership: 100,
      progressPercentage: initialPct,
      estimatedCompletionDate: null,
      totalPayments: 0,
      completedPayments: 0,
      projected: true,
      hasOverdue: false,
    };
  }

  const tenureForCalc = tenorMonths > 0 ? tenorMonths : schedules.length;
  const milestones: OwnershipMilestone[] = [];
  let completedPayments = 0;
  let lastPaidIndex = -1;
  let hasOverdue = false;

  schedules.forEach((payment, index) => {
    const { customerOwnership, bloxOwnership } = calculateOwnership(
      vehiclePrice,
      downPayment,
      tenureForCalc,
      index,
    );
    const ownershipPercentage =
      vehiclePrice > 0
        ? Math.round((customerOwnership / vehiclePrice) * 10000) / 100
        : 0;
    const status = paymentStatus(payment.status, payment.dueDate);

    if (status === 'paid') {
      completedPayments++;
      lastPaidIndex = index;
    }
    if (status === 'missed') hasOverdue = true;

    const { milestone, labelKey } = milestoneForPercentage(ownershipPercentage, index);

    milestones.push({
      date: payment.dueDate,
      ownershipPercentage,
      ownershipAmount: Math.round(customerOwnership * 100) / 100,
      customerShare: Math.round(customerOwnership * 100) / 100,
      bloxShare: Math.round(bloxOwnership * 100) / 100,
      paymentIndex: index,
      paymentStatus: status,
      milestone,
      labelKey,
      sequence: payment.sequence,
    });
  });

  const currentOwnership =
    lastPaidIndex >= 0
      ? milestones[lastPaidIndex].ownershipPercentage
      : vehiclePrice > 0
        ? Math.round((downPayment / vehiclePrice) * 10000) / 100
        : 0;

  const currentOwnershipAmount =
    lastPaidIndex >= 0
      ? milestones[lastPaidIndex].ownershipAmount
      : downPayment;

  const bloxOwnership = Math.max(vehiclePrice - currentOwnershipAmount, 0);

  const remainingPayments = schedules.length - completedPayments;
  const estimatedCompletionDate =
    remainingPayments > 0 && schedules.length > 0
      ? schedules[schedules.length - 1].dueDate
      : null;

  return {
    milestones,
    currentOwnership,
    currentOwnershipAmount,
    bloxOwnership,
    vehiclePrice,
    downPayment,
    targetOwnership: 100,
    progressPercentage: currentOwnership,
    estimatedCompletionDate,
    totalPayments: schedules.length,
    completedPayments,
    projected: !(paymentSchedules && paymentSchedules.length > 0),
    hasOverdue,
  };
}

export function filterKeyMilestones(milestones: OwnershipMilestone[]): OwnershipMilestone[] {
  return milestones.filter((m, index) => {
    if (index === 0 || index === milestones.length - 1) return true;
    if (m.milestone) return true;
    return index % 4 === 0;
  });
}
