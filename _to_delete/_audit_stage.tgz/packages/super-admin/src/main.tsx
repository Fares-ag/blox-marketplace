import { StrictMode, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider, CssBaseline } from '@mui/material';
import {
  AuthGuard,
  LoginPage,
  BloxShell,
  bloxThemeWithBrand,
  useAuthStore,
  OpsPageHeader,
  OpsStatusPill,
  OpsDataTable,
  OpsStatCard,
  ScrollToTop,
  type BloxNavItem,
} from '@drivemarket/shared';

const queryClient = new QueryClient();
const nav: BloxNavItem[] = [
  { to: '/', label: 'Users', icon: 'users' },
  { to: '/companies', label: 'Companies', icon: 'company' },
  { to: '/activity-logs', label: 'Activity logs', icon: 'logs' },
  { to: '/system', label: 'System', icon: 'system' },
];

const users = [
  { email: 'admin@drivemarket.local', role: 'admin', company: '—' },
  { email: 'dealer@drivemarket.local', role: 'dealer_agent', company: 'Gulf Motors Demo' },
  { email: 'credit@drivemarket.local', role: 'credit_officer', company: '—' },
  { email: 'finance@drivemarket.local', role: 'finance_officer', company: '—' },
  { email: 'super@drivemarket.local', role: 'super_admin', company: '—' },
];

const companies = [
  { name: 'Gulf Motors Demo', code: 'GULF', status: 'active', published: 4 },
  { name: 'Doha Auto Gallery', code: 'DAG', status: 'draft', published: 0 },
];

const logs = [
  { at: '2026-08-05 21:14', actor: 'admin@drivemarket.local', action: 'company.update', detail: 'GULF can_pay=true' },
  { at: '2026-08-05 18:02', actor: 'credit@drivemarket.local', action: 'application.transition', detail: 'APP-2400 → approved' },
  { at: '2026-08-04 11:40', actor: 'dealer@drivemarket.local', action: 'product.publish', detail: 'hyundai-tucson-limited' },
];

function UsersPage() {
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Users & roles"
        subtitle="Assign roles including super_admin"
        actions={
          <button type="button" className="blox-btn blox-btn--primary">
            Invite user
          </button>
        }
      />
      <OpsDataTable
        columns={['Email', 'Role', 'Company']}
        rows={users.map((u) => [
          u.email,
          <OpsStatusPill key="r" label={u.role} variant="active" />,
          u.company,
        ])}
      />
    </div>
  );
}

function CompaniesPage() {
  return (
    <div className="blox-page">
      <OpsPageHeader title="Companies" subtitle="Cross-tenant oversight" />
      <OpsDataTable
        columns={['Name', 'Code', 'Status', 'Published']}
        rows={companies.map((c) => [
          c.name,
          c.code,
          <OpsStatusPill key="s" label={c.status} variant={c.status === 'active' ? 'active' : 'draft'} />,
          <span key="p" className="blox-money">
            {c.published}
          </span>,
        ])}
      />
    </div>
  );
}

function ActivityLogsPage() {
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Activity logs"
        subtitle="Audit trail across ops actions"
        actions={
          <button type="button" className="blox-btn blox-btn--primary">
            Export
          </button>
        }
      />
      <OpsDataTable
        columns={['When', 'Actor', 'Action', 'Detail']}
        rows={logs.map((l) => [l.at, l.actor, l.action, l.detail])}
      />
    </div>
  );
}

function SystemPage() {
  return (
    <div className="blox-page">
      <OpsPageHeader title="System" subtitle="Feature flags and monitoring links" />
      <div className="blox-stat-grid">
        <OpsStatCard label="API" value="Healthy" delta="localhost:3010" />
        <OpsStatCard label="Payments" value="Sandbox" delta="SkipCash" />
        <OpsStatCard label="Featured listings" value="Off" delta="Flag disabled" />
        <OpsStatCard label="Can pay default" value="On" delta="New dealers" />
      </div>
    </div>
  );
}

function App() {
  const init = useAuthStore((s) => s.init);
  useEffect(() => {
    void init();
  }, [init]);
  return (
    <Routes>
      <Route path="/auth/login" element={<LoginPage portalLabel="Blox Super Admin" homePath="/" />} />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="super_admin" reasonParam="not_super_admin">
            <BloxShell title="Super Admin" nav={nav}>
              <Routes>
                <Route path="/" element={<UsersPage />} />
                <Route path="/companies" element={<CompaniesPage />} />
                <Route path="/activity-logs" element={<ActivityLogsPage />} />
                <Route path="/system" element={<SystemPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={bloxThemeWithBrand}>
        <CssBaseline />
        <BrowserRouter>
          <ScrollToTop />
          <App />
        </BrowserRouter>
      </ThemeProvider>
    </QueryClientProvider>
  </StrictMode>,
);
