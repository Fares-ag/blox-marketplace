import { Link, Navigate, Route, Routes, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { FormEvent, useEffect, useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import {
  AuthGuard,
  GuestGuard,
  LoginPage,
  RegisterPage,
  MoneyText,
  DocumentMeta,
  apiFetch,
  bloxMeta,
  BloxLogo,
  estimateMonthlyPayment,
  formatQar,
  getAppLocale,
  type ProductDetailResponse,
  type ProductListResponse,
  type PublicCompany,
  useAuthStore,
} from '@drivemarket/shared';
import { ListingCard } from './components/ListingCard';
import {
  FacetPanel,
  FacetMobileTrigger,
  buildProductsQuery,
  parseBrowseParams,
  type BrowseSort,
} from './components/FacetPanel';
import { ImageGallery, VehicleSpecGrid } from './components/VehicleDetailParts';
import { ListingCtaPanel, MobileStickyApplyBar } from './components/ListingCtaPanel';
import { StakePreview } from './components/StakePreview';
import { MarketplaceNav } from './components/MarketplaceNav';
import { ComparePage } from './pages/ComparePage';
import { HelpPage } from './pages/HelpPage';
import { CustomerDashboardPage } from './pages/CustomerDashboardPage';
import { ApplicationDetailPanel } from './components/ApplicationDetailPanel';

function HomePage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const { data: arrivals } = useQuery({
    queryKey: ['products', 'new-arrivals'],
    queryFn: () => apiFetch<ProductListResponse>('/api/products?sort=newest&limit=8'),
  });

  const categories = [
    { to: '/vehicles', label: t('home.catAll'), icon: 'all' },
    { to: '/vehicles?condition=new', label: t('home.catNew'), icon: 'new' },
    { to: '/vehicles?condition=used', label: t('home.catUsed'), icon: 'used' },
    { to: '/vehicles?bodyType=suv', label: t('home.catSuv'), icon: 'suv' },
    { to: '/vehicles?bodyType=sedan', label: t('home.catSedan'), icon: 'sedan' },
    { to: '/vehicles?bodyType=pickup', label: t('home.catPickup'), icon: 'pickup' },
    { to: '/dealers', label: t('home.catDealers'), icon: 'dealers' },
    { to: '/help', label: t('home.catFinance'), icon: 'finance' },
  ] as const;

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    const trimmed = q.trim();
    if (trimmed) params.set('q', trimmed);
    navigate(`/vehicles${params.toString() ? `?${params}` : ''}`);
  }

  return (
    <div className="dm-home">
      <DocumentMeta title={t('meta.homeTitle')} />
      <MarketplaceNav variant="solid" />
      <section className="dm-market-hero" aria-label="Blox market">
        <div className="dm-market-hero__inner">
          <p className="dm-market-hero__brand">
            <BloxLogo height={56} tone="onDark" alt={bloxMeta.name} />
          </p>
          <h1 className="dm-market-hero__headline">{t('home.headline')}</h1>
          <p className="dm-market-hero__support">{t('home.support')}</p>
          <form className="dm-market-search" onSubmit={onSearch}>
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t('home.searchPlaceholder')}
              aria-label={t('home.searchPlaceholder')}
            />
            <button type="submit" className="dm-btn-cta">
              {t('home.search')}
            </button>
          </form>
        </div>
        <div className="dm-market-hero__glow" aria-hidden />
      </section>
      <section className="dm-market-cats" aria-label={t('home.marketTitle')}>
        <h2 className="dm-market-cats__title">{t('home.marketTitle')}</h2>
        <div className="dm-market-cats__grid">
          {categories.map((cat) => (
            <Link key={cat.to} to={cat.to} className="dm-market-cat">
              <span className={`dm-market-cat__icon dm-market-cat__icon--${cat.icon}`} aria-hidden>
                <CategoryGlyph kind={cat.icon} />
              </span>
              <span className="dm-market-cat__label">{cat.label}</span>
            </Link>
          ))}
        </div>
      </section>
      {(arrivals?.items.length ?? 0) > 0 && (
        <section className="dm-new-arrivals">
          <div className="dm-new-arrivals__head">
            <div>
              <h2>{t('home.newArrivals')}</h2>
              <p>{t('home.newArrivalsBody')}</p>
            </div>
            <Link to="/vehicles?sort=newest">{t('home.viewAll')}</Link>
          </div>
          <div className="dm-new-arrivals__list">
            {arrivals!.items.map((p) => (
              <ListingCard key={p.id} product={p} variant="row" />
            ))}
          </div>
        </section>
      )}
      <section className="dm-below">
        <h2>{t('home.readyTitle')}</h2>
        <p>{t('home.readyBody')}</p>
        <Link to="/vehicles">{t('home.goSearch')}</Link>
      </section>
      <style>{`
        .dm-home { background: var(--dm-canvas); min-height: 100vh; }
        .dm-market-hero {
          position: relative;
          overflow: hidden;
          background:
            linear-gradient(135deg, rgba(15,63,69,0.92) 0%, rgba(22,83,91,0.78) 55%, rgba(0,207,162,0.35) 100%),
            url('https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=2400&q=80') center / cover no-repeat;
          color: #fff;
        }
        .dm-market-hero__inner {
          position: relative;
          z-index: 1;
          max-width: 720px;
          margin: 0 auto;
          padding: 48px 24px 56px;
          text-align: center;
          animation: dm-fade 220ms var(--dm-ease) both;
        }
        @media (min-width: 1440px) {
          .dm-market-hero__inner {
            max-width: 880px;
            padding: 64px 32px 72px;
          }
          .dm-market-hero__headline { font-size: clamp(1.6rem, 2.2vw, 2.15rem); }
          .dm-market-search { max-width: 640px; }
        }
        @media (min-width: 1920px) {
          .dm-market-hero__inner {
            max-width: 960px;
            padding: 72px 40px 80px;
          }
        }
        .dm-market-hero__glow {
          position: absolute;
          inset: auto -10% -40% auto;
          width: 55%;
          height: 70%;
          background: radial-gradient(circle, rgba(219,255,0,0.18), transparent 70%);
          pointer-events: none;
        }
        .dm-market-hero__brand {
          margin: 0 0 14px;
          line-height: 0;
          display: flex;
          justify-content: center;
        }
        .dm-market-hero__headline {
          margin: 0 0 12px;
          font-family: var(--dm-font-display);
          font-size: clamp(1.35rem, 3vw, 1.85rem);
          font-weight: 600;
          line-height: 1.2;
        }
        .dm-market-hero__support {
          margin: 0 auto 28px;
          max-width: 46ch;
          color: rgba(255,255,255,0.85);
          font-size: 1.02rem;
          line-height: 1.5;
        }
        .dm-market-search {
          display: flex;
          gap: 10px;
          max-width: 560px;
          margin: 0 auto;
          padding: 8px;
          background: rgba(255,255,255,0.96);
          border-radius: 14px;
          box-shadow: 0 12px 40px rgba(15, 63, 69, 0.22);
        }
        .dm-market-search input {
          flex: 1;
          min-width: 0;
          border: none;
          background: transparent;
          padding: 12px 14px;
          font: inherit;
          color: var(--dm-ink);
          outline: none;
        }
        .dm-market-search .dm-btn-cta {
          border: none;
          border-radius: 10px;
          padding: 12px 20px;
          cursor: pointer;
          white-space: nowrap;
        }
        .dm-market-cats {
          max-width: min(100%, var(--bp-content-max, 1600px));
          margin: 0 auto;
          padding: 40px 24px 16px;
        }
        .dm-market-cats__title {
          margin: 0 0 28px;
          text-align: center;
          font-family: var(--dm-font-display);
          font-size: 1.35rem;
          font-weight: 600;
          color: var(--dm-ink);
        }
        .dm-market-cats__grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 28px 20px;
          justify-items: center;
        }
        .dm-market-cat {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          text-decoration: none;
          color: var(--dm-ink);
          width: 100%;
          max-width: 120px;
          transition: transform 180ms var(--dm-ease);
        }
        .dm-market-cat:hover { transform: translateY(-3px); }
        .dm-market-cat__icon {
          width: 88px;
          height: 88px;
          border-radius: 50%;
          display: grid;
          place-items: center;
          background: var(--dm-surface);
          border: 1px solid var(--dm-slate-200);
          box-shadow: 0 4px 18px rgba(15, 63, 69, 0.06);
          color: var(--dm-graphite-900);
          transition: border-color 180ms var(--dm-ease), box-shadow 180ms var(--dm-ease), background 180ms var(--dm-ease);
        }
        .dm-market-cat:hover .dm-market-cat__icon {
          border-color: var(--dm-steel);
          background: var(--dm-steel-soft);
          box-shadow: 0 8px 24px rgba(0, 207, 162, 0.16);
        }
        .dm-market-cat__label {
          font-size: 0.92rem;
          font-weight: 600;
          text-align: center;
          line-height: 1.25;
        }
        .dm-below {
          padding: 48px 24px 64px;
          max-width: 720px;
          margin: 0 auto;
          text-align: center;
        }
        .dm-below h2 { font-family: var(--dm-font-display); font-size: 1.5rem; margin: 0 0 12px; }
        .dm-below p { color: var(--dm-slate-600); line-height: 1.55; margin: 0 0 16px; }
        .dm-below a { font-weight: 600; color: var(--dm-steel); }
        .dm-new-arrivals {
          padding: 32px 24px 24px;
          border-top: 1px solid var(--dm-slate-200);
          background: var(--dm-surface);
        }
        .dm-new-arrivals__head {
          display: flex;
          flex-wrap: wrap;
          align-items: flex-end;
          justify-content: space-between;
          gap: 16px;
          max-width: min(100%, var(--bp-content-max, 1600px));
          margin: 0 auto 24px;
        }
        .dm-new-arrivals__head h2 {
          margin: 0 0 8px;
          font-family: var(--dm-font-display);
          font-size: 1.5rem;
        }
        .dm-new-arrivals__head p { margin: 0; color: var(--dm-slate-600); max-width: 42ch; }
        .dm-new-arrivals__head a { font-weight: 600; color: var(--dm-steel); }
        .dm-new-arrivals__list {
          display: flex;
          flex-direction: column;
          gap: 12px;
          max-width: min(100%, var(--bp-content-max, 1600px));
          margin: 0 auto;
        }
        @media (min-width: 1600px) {
          .dm-market-cats,
          .dm-new-arrivals__head,
          .dm-new-arrivals__list {
            max-width: min(100%, var(--bp-content-wide, 2000px));
          }
          .dm-market-cats__grid {
            grid-template-columns: repeat(8, minmax(0, 1fr));
          }
          .dm-new-arrivals__list {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
          }
        }
        @media (min-width: 1920px) {
          .dm-market-cats,
          .dm-new-arrivals__head,
          .dm-new-arrivals__list {
            max-width: min(100%, var(--bp-content-ultra, 2560px));
          }
          .dm-new-arrivals__list {
            gap: 14px;
          }
        }
        @media (min-width: 2560px) {
          .dm-market-cats,
          .dm-new-arrivals__head,
          .dm-new-arrivals__list {
            max-width: min(100%, 2800px);
          }
        }
        @keyframes dm-fade { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
        @media (max-width: 720px) {
          .dm-market-cats__grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 22px 12px; }
          .dm-market-search { flex-direction: column; }
          .dm-market-search .dm-btn-cta { width: 100%; }
          .dm-market-cat__icon { width: 76px; height: 76px; }
          .dm-market-hero__inner { padding: 36px 16px 44px; }
          .dm-new-arrivals { padding: 24px var(--blox-page-gutter, 16px); }
          .dm-below { padding: 40px var(--blox-page-gutter, 16px) 56px; }
        }
        @media (max-width: 400px) {
          .dm-market-cats__grid { grid-template-columns: 1fr 1fr; gap: 16px 10px; }
          .dm-market-cat__icon { width: 64px; height: 64px; }
        }
      `}</style>
    </div>
  );
}

function CategoryGlyph({ kind }: { kind: string }) {
  const common = { width: 36, height: 36, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.6 } as const;
  switch (kind) {
    case 'new':
      return (
        <svg {...common}>
          <path d="M12 3l1.8 5.5H19l-4.4 3.2 1.7 5.3L12 14.8 7.7 17l1.7-5.3L5 8.5h5.2L12 3z" />
        </svg>
      );
    case 'used':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8" />
          <path d="M12 8v4l2.5 1.5" />
        </svg>
      );
    case 'suv':
      return (
        <svg {...common}>
          <path d="M4 15h16v2.5H4zM6 15l1.5-5h9L18 15" />
          <circle cx="7.5" cy="17.5" r="1.4" />
          <circle cx="16.5" cy="17.5" r="1.4" />
          <path d="M8 10h8" />
        </svg>
      );
    case 'sedan':
      return (
        <svg {...common}>
          <path d="M3.5 14.5h17v2H3.5zM5 14.5l1.8-4.2h10.4L19 14.5" />
          <circle cx="7" cy="16.8" r="1.3" />
          <circle cx="17" cy="16.8" r="1.3" />
          <path d="M9 10.3h6" />
        </svg>
      );
    case 'pickup':
      return (
        <svg {...common}>
          <path d="M3 15h18v2H3zM4.5 15l1.2-4H11v4M12 11h5.5L19.5 15" />
          <circle cx="7" cy="17.2" r="1.3" />
          <circle cx="16.5" cy="17.2" r="1.3" />
        </svg>
      );
    case 'dealers':
      return (
        <svg {...common}>
          <path d="M4 19V9l8-5 8 5v10" />
          <path d="M9 19v-6h6v6" />
        </svg>
      );
    case 'finance':
      return (
        <svg {...common}>
          <rect x="4" y="6" width="16" height="12" rx="2" />
          <path d="M4 10h16M8 14h3" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <path d="M3.5 15h17v2H3.5zM5 15l2-5h10l2 5" />
          <circle cx="7.5" cy="17.2" r="1.3" />
          <circle cx="16.5" cy="17.2" r="1.3" />
          <path d="M9 10h6M8 7.5h8" />
        </svg>
      );
  }
}


function VehiclesPage() {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const browse = useMemo(() => parseBrowseParams(searchParams), [searchParams]);
  const browseKey = useMemo(
    () => JSON.stringify({ filters: browse.filters, sort: browse.sort }),
    [browse.filters, browse.sort],
  );
  const queryString = buildProductsQuery(browse.filters, {
    sort: browse.sort,
    offset: browse.offset,
    limit: browse.limit,
  });

  const [allItems, setAllItems] = useState<ProductListResponse['items']>([]);
  const [facetOpen, setFacetOpen] = useState(false);

  useEffect(() => {
    setAllItems([]);
  }, [browseKey]);

  const dealers = useQuery({
    queryKey: ['companies-public'],
    queryFn: () => apiFetch<PublicCompany[]>('/api/companies'),
  });

  const { data, isLoading, error, isFetching } = useQuery({
    queryKey: ['products', queryString],
    queryFn: () => apiFetch<ProductListResponse>(`/api/products${queryString}`),
  });

  useEffect(() => {
    if (!data?.items) return;
    if (browse.offset === 0) {
      setAllItems(data.items);
    } else {
      setAllItems((prev) => {
        const ids = new Set(prev.map((p) => p.id));
        const next = [...prev];
        for (const item of data.items) {
          if (!ids.has(item.id)) next.push(item);
        }
        return next;
      });
    }
  }, [data, browse.offset]);

  function onSortChange(sort: BrowseSort) {
    const next = new URLSearchParams(searchParams);
    if (sort === 'newest') next.delete('sort');
    else next.set('sort', sort);
    next.delete('offset');
    setSearchParams(next);
  }

  function loadMore() {
    const next = new URLSearchParams(searchParams);
    next.set('offset', String(browse.offset + browse.limit));
    setSearchParams(next);
  }

  const shown = allItems.length > 0 ? allItems : data?.items ?? [];
  const total = data?.total ?? 0;
  const hasMore = total > browse.offset + (data?.items.length ?? 0);

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <DocumentMeta title={t('meta.vehiclesTitle')} />
      <MarketplaceNav variant="solid" />
      <div className="dm-browse-pagehead">
        <h1>{t('vehicles.title')}</h1>
        <p>{t('vehicles.subtitle')}</p>
      </div>
      <div className="blox-browse-layout">
        <FacetPanel dealers={dealers.data ?? []} variant="top" />
        <div className="blox-browse-results">
          <div className="dm-browse-toolbar">
            <FacetMobileTrigger
              dealers={dealers.data ?? []}
              open={facetOpen}
              onOpenChange={setFacetOpen}
            />
            <label className="dm-browse-sort">
              <span>{t('vehicles.sort')}</span>
              <select value={browse.sort} onChange={(e) => onSortChange(e.target.value as BrowseSort)}>
                <option value="newest">{t('vehicles.sortNewest')}</option>
                <option value="price_asc">{t('vehicles.sortPriceAsc')}</option>
                <option value="price_desc">{t('vehicles.sortPriceDesc')}</option>
                <option value="year_desc">{t('vehicles.sortYearDesc')}</option>
                <option value="mileage_asc">{t('vehicles.sortMileageAsc')}</option>
              </select>
            </label>
          </div>
          {data && (
            <p className="dm-browse-count">
              {shown.length > 0
                ? t('vehicles.showing', {
                    from: 1,
                    to: Math.min(shown.length, total),
                    total,
                  })
                : t('vehicles.count', { count: total })}
            </p>
          )}
          {isLoading && shown.length === 0 && <p>{t('vehicles.loading')}</p>}
          {error && <p style={{ color: 'var(--dm-danger)' }}>{(error as Error).message}</p>}
          {!isLoading && shown.length === 0 && (
            <p style={{ color: 'var(--dm-slate-600)' }}>{t('vehicles.noResults')}</p>
          )}
          <div className="dm-listing-stack">
            {shown.map((p) => (
              <ListingCard key={p.id} product={p} variant="row" />
            ))}
          </div>
          {hasMore && (
            <div className="dm-browse-load-more">
              <button type="button" className="dm-btn-ghost" onClick={loadMore} disabled={isFetching}>
                {isFetching ? t('vehicles.loading') : t('vehicles.loadMore')}
              </button>
            </div>
          )}
        </div>
      </div>
      <style>{`
        .dm-browse-pagehead {
          max-width: min(100%, var(--bp-content-max, 1600px));
          margin: 0 auto;
          padding: 20px var(--blox-page-gutter, 32px) 0;
        }
        .dm-browse-pagehead h1 {
          margin: 0 0 6px;
          font-family: var(--dm-font-display);
          font-size: 1.75rem;
          color: var(--dm-ink);
        }
        .dm-browse-pagehead p {
          margin: 0;
          color: var(--dm-slate-600);
        }
        .blox-browse-results {
          display: flex;
          flex-direction: column;
          gap: 0;
          min-width: 0;
        }
        .dm-browse-toolbar {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          justify-content: flex-end;
          gap: 12px;
          margin-bottom: 12px;
        }
        .dm-browse-count {
          color: var(--dm-slate-600);
          margin: 0 0 16px;
          font-size: 14px;
        }
        .dm-listing-stack {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        @media (min-width: 1600px) {
          .dm-listing-stack {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
          }
        }
        @media (min-width: 1920px) {
          .dm-listing-stack { gap: 14px; }
        }
        @media (min-width: 2560px) {
          .dm-listing-stack { gap: 16px; }
        }
        .dm-browse-load-more {
          margin-top: 24px;
          text-align: center;
        }
        .dm-browse-sort {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          color: var(--dm-slate-600);
        }
        .dm-browse-sort select {
          min-height: 40px;
          border-radius: 8px;
          border: 1px solid var(--dm-slate-200);
          padding: 0 10px;
          background: #fff;
        }
        @media (max-width: 900px) {
          .dm-browse-pagehead { padding: 16px var(--blox-page-gutter, 20px) 0; }
          .dm-browse-toolbar {
            justify-content: space-between;
            gap: 10px;
          }
          .dm-browse-sort { width: auto; flex: 1; min-width: 0; justify-content: flex-end; }
          .dm-browse-sort select { flex: 1; min-width: 0; max-width: 220px; }
        }
        @media (min-width: 1600px) {
          .dm-browse-pagehead {
            max-width: min(100%, var(--bp-content-wide, 2000px));
          }
        }
        @media (min-width: 1920px) {
          .dm-browse-pagehead { max-width: min(100%, var(--bp-content-ultra, 2560px)); }
        }
        @media (min-width: 2560px) {
          .dm-browse-pagehead { max-width: min(100%, 2800px); }
        }
      `}</style>
    </div>
  );
}

function VehicleDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const locale = getAppLocale();
  const { data, isLoading } = useQuery({
    queryKey: ['product', slug],
    queryFn: () => apiFetch<ProductDetailResponse>(`/api/products/by-slug/${slug}`),
    enabled: !!slug,
  });

  const product = data?.product;
  const offer = data?.offer;
  const company = data?.company;
  const images = data?.images ?? [];

  const [tenure, setTenure] = useState(36);
  const [downPct, setDownPct] = useState(10);

  useEffect(() => {
    if (offer?.min_down_payment_pct != null) setDownPct(Number(offer.min_down_payment_pct));
    if (offer?.tenure_options?.length) setTenure(Number(offer.tenure_options[2] ?? offer.tenure_options[0]));
  }, [offer]);

  const monthly = useMemo(() => {
    if (!product || !offer) return 0;
    const down = (product.price * downPct) / 100;
    return estimateMonthlyPayment({
      price: product.price,
      downPayment: down,
      annualRatePercent: offer.annual_rent_rate,
      tenureMonths: tenure,
    });
  }, [product, offer, downPct, tenure]);

  if (isLoading) return <p style={{ padding: 48 }}>{t('vehicles.loading')}</p>;
  if (!data?.available || !product) {
    return (
      <div style={{ padding: 48 }}>
        <DocumentMeta title={t('detail.unavailable')} />
        <MarketplaceNav variant="solid" />
        <h1 style={{ fontFamily: 'var(--dm-font-display)', marginTop: 24 }}>{t('detail.unavailable')}</h1>
        <p>{t('detail.unavailableBody')}</p>
        <Link to="/vehicles">{t('detail.back')}</Link>
      </div>
    );
  }

  const metaTitle = t('meta.detailTitle', {
    make: product.make,
    model: product.model,
    year: product.model_year,
  });
  const metaDesc = t('meta.detailDescription', {
    make: product.make,
    model: product.model,
    year: product.model_year,
    price: formatQar(product.price, false, locale),
    dealer: company?.name ?? '',
  });

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <DocumentMeta title={metaTitle} description={metaDesc} />
      <MarketplaceNav variant="solid" />
      <div className="blox-detail-layout">
        <div>
          <ImageGallery images={images} />
          <h1 className="blox-detail-title">
            {product.make} {product.model}
            {product.trim ? ` ${product.trim}` : ''}
          </h1>
          {company && (
            <div className="blox-detail-dealer">
              {company.logo_url && (
                <img src={company.logo_url} alt="" style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover' }} />
              )}
              <div>
                <div style={{ fontSize: 13, color: 'var(--dm-slate-600)' }}>{t('detail.soldBy')}</div>
                {company.code ? (
                  <Link to={`/dealers/${company.code}`} style={{ fontWeight: 600 }}>
                    {company.name}
                  </Link>
                ) : (
                  <span style={{ fontWeight: 600 }}>{company.name}</span>
                )}
              </div>
            </div>
          )}
          <p>{product.description}</p>
          <VehicleSpecGrid product={product} />
        </div>
        <ListingCtaPanel
          price={product.price}
          financeEligible={product.finance_eligible}
          availability={data.availability}
          companyCode={company?.code}
          companyName={company?.name}
          contactPhone={company?.contact_phone}
          listingTitle={`${product.make} ${product.model}${product.trim ? ` ${product.trim}` : ''} ${product.model_year}`}
          monthlyEstimate={offer ? monthly : null}
          onApply={() =>
            navigate(
              `/app/applications/new?product=${slug}&tenure=${tenure}&downPct=${downPct}`,
            )
          }
        >
          {offer && (
            <>
              <label style={{ display: 'block', marginBottom: 12, fontSize: 14 }}>
                {t('detail.tenure')}
                <select value={tenure} onChange={(e) => setTenure(Number(e.target.value))} style={{ display: 'block', width: '100%', minHeight: 40, marginTop: 6 }}>
                  {(offer.tenure_options || [12, 24, 36, 48, 60]).map((mo) => (
                    <option key={mo} value={mo}>{mo}</option>
                  ))}
                </select>
              </label>
              <label style={{ display: 'block', marginBottom: 8, fontSize: 14 }}>
                {t('detail.downPayment')}
                <input
                  type="number"
                  min={offer.min_down_payment_pct}
                  max={80}
                  value={downPct}
                  onChange={(e) => setDownPct(Number(e.target.value))}
                  style={{ display: 'block', width: '100%', minHeight: 40, marginTop: 6 }}
                />
              </label>
              <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', margin: 0 }}>{t('detail.estimateNote')}</p>
              <StakePreview downPct={downPct} tenureMonths={tenure} />
            </>
          )}
        </ListingCtaPanel>
      </div>
      <MobileStickyApplyBar
        price={product.price}
        financeEligible={product.finance_eligible}
        monthlyEstimate={offer ? monthly : null}
        contactPhone={company?.contact_phone}
        onApply={() =>
          navigate(`/app/applications/new?product=${slug}&tenure=${tenure}&downPct=${downPct}`)
        }
      />
    </div>
  );
}

function DealersDirectoryPage() {
  const { t } = useTranslation();
  const { data, isLoading } = useQuery({
    queryKey: ['companies-public'],
    queryFn: () => apiFetch<PublicCompany[]>('/api/companies'),
  });

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <DocumentMeta title={t('meta.dealersTitle')} />
      <MarketplaceNav variant="solid" />
      <div className="dm-page-head dm-page-head--brand">
        <h1>{t('dealers.title')}</h1>
        <p>{t('dealers.subtitle')}</p>
      </div>
      <div className="blox-page-pad">
        {isLoading && <p>{t('vehicles.loading')}</p>}
        {!isLoading && !data?.length && <p style={{ color: 'var(--dm-slate-600)' }}>{t('dealers.empty')}</p>}
        <div style={{ display: 'grid', gap: 16, maxWidth: 'min(100%, var(--bp-content-max, 1600px))', margin: '0 auto', width: '100%' }}>
          {data?.filter((d) => (d.published_count ?? 0) > 0).map((d) => (
            <Link
              key={d.id}
              to={d.code ? `/dealers/${d.code}` : '/vehicles'}
              className="dm-dealer-row"
            >
              {d.logo_url ? (
                <img src={d.logo_url} alt="" className="dm-dealer-row__logo" />
              ) : (
                <div className="dm-dealer-row__logo dm-dealer-row__logo--empty" />
              )}
              <div className="dm-dealer-row__body">
                <div className="dm-dealer-row__name">{d.name}</div>
                <div className="dm-dealer-row__meta">
                  {t('dealers.listings', { count: d.published_count ?? 0 })}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      <style>{`
        .dm-dealer-row {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 16px 18px;
          background: var(--dm-surface);
          border-radius: 16px;
          border: 1px solid var(--dm-slate-200);
          text-decoration: none;
          color: inherit;
          min-width: 0;
        }
        .dm-dealer-row__logo {
          width: 56px;
          height: 56px;
          border-radius: 12px;
          object-fit: cover;
          flex-shrink: 0;
        }
        .dm-dealer-row__logo--empty {
          background: var(--dm-slate-100);
        }
        .dm-dealer-row__body { min-width: 0; }
        .dm-dealer-row__name {
          font-family: var(--dm-font-display);
          font-size: clamp(1rem, 3vw, 1.125rem);
          font-weight: 600;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .dm-dealer-row__meta {
          color: var(--dm-slate-600);
          font-size: 13px;
        }
        @media (max-width: 480px) {
          .dm-dealer-row { gap: 12px; padding: 14px; }
          .dm-dealer-row__logo { width: 48px; height: 48px; }
        }
      `}</style>
    </div>
  );
}

function DealerShowroomPage() {
  const { code } = useParams();
  const { t } = useTranslation();
  const company = useQuery({
    queryKey: ['company-by-code', code],
    queryFn: () => apiFetch<PublicCompany & { address?: string; contact_phone?: string } | null>(`/api/companies/by-code/${code}`),
    enabled: !!code,
  });

  const products = useQuery({
    queryKey: ['products', 'company', company.data?.id],
    queryFn: () => apiFetch<ProductListResponse>(`/api/products?companyId=${company.data!.id}`),
    enabled: !!company.data?.id,
  });

  if (company.isLoading) return <p style={{ padding: 48 }}>{t('vehicles.loading')}</p>;
  if (!company.data) return <Navigate to="/dealers" replace />;

  const c = company.data;
  const metaTitle = t('meta.showroomTitle', { name: c.name });

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <DocumentMeta title={metaTitle} />
      <MarketplaceNav variant="solid" />
      <div className="dm-page-head dm-page-head--brand">
        <div className="dm-page-head__row">
          {c.logo_url && (
            <img
              src={c.logo_url}
              alt=""
              style={{ width: 56, height: 56, borderRadius: 12, objectFit: 'cover', flexShrink: 0 }}
            />
          )}
          <div style={{ minWidth: 0 }}>
            <h1>{t('dealers.showroomTitle', { name: c.name })}</h1>
            <p>{t('dealers.showroomBody')}</p>
          </div>
        </div>
      </div>
      <div className="blox-page-pad blox-content-wide">
        <p style={{ color: 'var(--dm-slate-600)' }}>{t('dealers.listings', { count: products.data?.total ?? 0 })}</p>
        <div className="dm-listing-stack">
          {products.data?.items.map((p) => (
            <ListingCard key={p.id} product={p} variant="row" />
          ))}
        </div>
      </div>
    </div>
  );
}

function ApplyWizardPage() {
  const [params] = useSearchParams();
  const productSlug = params.get('product') || '';
  const quoteToken = params.get('quote') || '';
  const tenureParam = Number(params.get('tenure') || 36);
  const downPctParam = Number(params.get('downPct') || 10);
  const navigate = useNavigate();
  const { t } = useTranslation();
  const qc = useQueryClient();
  const locale = getAppLocale();
  const detail = useQuery({
    queryKey: ['product', productSlug],
    queryFn: () => apiFetch<ProductDetailResponse>(`/api/products/by-slug/${productSlug}`),
    enabled: !!productSlug,
  });
  const quote = useQuery({
    queryKey: ['quote', quoteToken],
    queryFn: () =>
      apiFetch<{
        gate: string;
        negotiatedPrice?: number;
        offer?: ProductDetailResponse['offer'];
        product?: { id: string; slug: string };
      }>(`/api/quotes/${quoteToken}`),
    enabled: !!quoteToken,
  });
  const financePartners = useQuery({
    queryKey: ['finance-partners'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          code: string;
          name: string;
          crmAdapter: string;
          offers: Array<{
            id: string;
            name: string;
            annualRentRate: string | number;
            minDownPaymentPct: string | number;
            tenureOptions: number[];
          }>;
        }>
      >('/api/finance-partners'),
  });
  const product = detail.data?.product;
  const defaultOffer =
    quoteToken && quote.data?.gate === 'active' ? quote.data.offer : detail.data?.offer;
  const [financePartnerId, setFinancePartnerId] = useState('');
  const selectedPartner = financePartners.data?.find((p) => p.id === financePartnerId);
  const partnerOffer = selectedPartner?.offers[0];
  const offer = partnerOffer
    ? {
        id: partnerOffer.id,
        annual_rent_rate: Number(partnerOffer.annualRentRate),
        min_down_payment_pct: Number(partnerOffer.minDownPaymentPct),
        tenure_options: (partnerOffer.tenureOptions ?? []).map(Number),
      }
    : defaultOffer;
  const financePrice =
    quoteToken && quote.data?.gate === 'active' && quote.data.negotiatedPrice != null
      ? quote.data.negotiatedPrice
      : product?.price ?? 0;

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [qid, setQid] = useState('');
  const [employment, setEmployment] = useState('');
  const [income, setIncome] = useState('');
  const [tenure, setTenure] = useState(tenureParam);
  const [downPct, setDownPct] = useState(downPctParam);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!financePartners.data?.length || financePartnerId) return;
    setFinancePartnerId(financePartners.data[0].id);
  }, [financePartners.data, financePartnerId]);

  useEffect(() => {
    if (!offer) return;
    const minDown = Number(offer.min_down_payment_pct ?? 10);
    setDownPct((prev) => Math.max(prev, minDown));
    const options = offer.tenure_options?.map(Number) ?? [12, 24, 36, 48, 60];
    if (!options.includes(tenure)) {
      setTenure(options.includes(36) ? 36 : options[0]);
    }
  }, [offer, tenure]);

  const monthlyPreview = useMemo(() => {
    if (!product || !offer) return 0;
    const down = (financePrice * downPct) / 100;
    return estimateMonthlyPayment({
      price: financePrice,
      downPayment: down,
      annualRatePercent: offer.annual_rent_rate,
      tenureMonths: tenure,
    });
  }, [product, offer, downPct, tenure, financePrice]);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!product || !offer) throw new Error('listing_not_available');
      if (!financePartnerId) throw new Error('finance_partner_required');
      const minDown = Number(offer.min_down_payment_pct ?? 0);
      const safeDownPct = Math.max(downPct, minDown);
      const down = (financePrice * safeDownPct) / 100;
      const monthly = estimateMonthlyPayment({
        price: financePrice,
        downPayment: down,
        annualRatePercent: offer.annual_rent_rate,
        tenureMonths: tenure,
      });
      return apiFetch<{ id: string }>('/api/applications', {
        method: 'POST',
        body: JSON.stringify({
          productId: product.id,
          offerId: offer.id,
          financePartnerId,
          quoteToken: quoteToken || undefined,
          customerSnapshot: {
            full_name: fullName,
            phone,
            qid,
            employment,
            income: Number(income) || 0,
          },
          pricingSnapshot: {
            list_price: financePrice,
            down_payment: down,
            down_payment_pct: safeDownPct,
            tenor: tenure,
            rate: offer.annual_rent_rate,
            monthly: Math.round(monthly),
          },
        }),
      });
    },
    onSuccess: (app: { id: string }) => {
      void qc.invalidateQueries({ queryKey: ['products'] });
      navigate(`/app/applications/${app.id}`);
    },
    onError: (e: Error) => {
      const msg = e.message;
      if (msg.includes('blocking_application') || msg.includes('409')) {
        setError('You already have an active application. Finish or withdraw it before applying again.');
        return;
      }
      if (msg.includes('quote_')) {
        setError('This special price link is no longer valid. Contact the dealer for a new link.');
        return;
      }
      setError(msg);
    },
  });

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    mutation.mutate();
  }

  if (!productSlug) return <Navigate to="/vehicles" replace />;
  if (quoteToken && quote.isLoading) {
    return <p style={{ padding: 48 }}>{t('vehicles.loading')}</p>;
  }
  if (quoteToken && quote.data && quote.data.gate !== 'active') {
    return <Navigate to={`/quotes/${quoteToken}`} replace />;
  }

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <MarketplaceNav variant="solid" />
      <div className="dm-flow-page">
        <h1>{t('detail.apply')}</h1>
        {product && (
          <p style={{ color: 'var(--dm-slate-600)' }}>
            {product.make} {product.model} ·{' '}
            {quoteToken ? (
              <>
                <MoneyText>{formatQar(financePrice, false, locale)}</MoneyText>
                {financePrice < product.price && (
                  <span style={{ marginLeft: 8, fontSize: 13 }}>
                    (special price; list {formatQar(product.price, false, locale)})
                  </span>
                )}
              </>
            ) : (
              <MoneyText>{formatQar(product.price, false, locale)}</MoneyText>
            )}
          </p>
        )}
        <p className="dm-apply-next" style={{ color: 'var(--dm-slate-600)', fontSize: 14, lineHeight: 1.55 }}>
          {t('application.nextSteps')}
        </p>
        {offer && product && (
          <div className="dm-flow-card">
            <label className="dm-flow-field">
              Finance company
              <select
                value={financePartnerId}
                onChange={(e) => setFinancePartnerId(e.target.value)}
                required
              >
                {(financePartners.data ?? []).map((partner) => (
                  <option key={partner.id} value={partner.id}>
                    {partner.name}
                    {partner.crmAdapter === 'zoho' ? ' · CRM linked' : ''}
                  </option>
                ))}
              </select>
            </label>
            {selectedPartner && partnerOffer && (
              <p style={{ margin: '0 0 8px', fontSize: 13, color: 'var(--dm-slate-600)' }}>
                {partnerOffer.name} · {Number(partnerOffer.annualRentRate)}% rate
              </p>
            )}
            <label className="dm-flow-field">
              {t('detail.tenure')}
              <select
                value={tenure}
                onChange={(e) => setTenure(Number(e.target.value))}
              >
                {(offer.tenure_options || [12, 24, 36, 48, 60]).map((mo) => (
                  <option key={mo} value={mo}>
                    {mo}
                  </option>
                ))}
              </select>
            </label>
            <label className="dm-flow-field">
              {t('detail.downPayment')}
              <input
                type="number"
                min={offer.min_down_payment_pct}
                max={80}
                value={downPct}
                onChange={(e) => setDownPct(Number(e.target.value))}
              />
            </label>
            <p style={{ margin: 0, fontSize: 14 }}>
              {t('detail.estMonthly')}:{' '}
              <MoneyText>{formatQar(Math.round(monthlyPreview), true, locale)}</MoneyText>
            </p>
          </div>
        )}
        <form onSubmit={onSubmit} className="dm-flow-form">
          {(
            [
              ['apply.fullName', setFullName, fullName],
              ['apply.phone', setPhone, phone],
              ['apply.qid', setQid, qid],
              ['apply.employment', setEmployment, employment],
              ['apply.monthlyIncome', setIncome, income],
            ] as const
          ).map(([labelKey, setter, value], i) => (
              <label key={labelKey} className="dm-flow-field">
                {t(labelKey)}
                <input
                  required={i < 3}
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                />
              </label>
            ))}
          {error && <p style={{ color: 'var(--dm-danger)' }}>{error}</p>}
          <button type="submit" className="dm-btn-cta" disabled={mutation.isPending}>
            {mutation.isPending ? t('vehicles.loading') : t('detail.applyContinue')}
          </button>
        </form>
      </div>
    </div>
  );
}

type QuoteResolveResponse = {
  gate: 'active' | 'requiresAuth' | 'wrongEmail' | 'expired' | 'used' | 'revoked' | 'notFound';
  token?: string;
  expiresAt?: string;
  customerEmailMasked?: string;
  negotiatedPrice?: number;
  listPriceSnapshot?: number;
  product?: {
    slug: string;
    make: string;
    model: string;
    trim?: string | null;
    modelYear: number;
    publicListPrice: number;
  };
  company?: { name: string };
  offer?: {
    annual_rent_rate: number;
    tenure_options: number[];
    min_down_payment_pct: number;
  };
};

function QuotePage() {
  const { token } = useParams();
  const { t } = useTranslation();
  const locale = getAppLocale();
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const signOut = useAuthStore((s) => s.signOut);
  const [tenure, setTenure] = useState(36);
  const [downPct, setDownPct] = useState(10);

  const { data, isLoading, error } = useQuery({
    queryKey: ['quote', token],
    queryFn: () => apiFetch<QuoteResolveResponse>(`/api/quotes/${token}`),
    enabled: !!token,
  });

  useEffect(() => {
    if (!data?.offer) return;
    const minDown = Number(data.offer.min_down_payment_pct ?? 10);
    setDownPct(minDown);
    const options = data.offer.tenure_options?.map(Number) ?? [36];
    setTenure(options.includes(36) ? 36 : options[0]);
  }, [data?.offer]);

  const monthly = useMemo(() => {
    if (!data?.negotiatedPrice || !data.offer) return 0;
    const down = (data.negotiatedPrice * downPct) / 100;
    return estimateMonthlyPayment({
      price: data.negotiatedPrice,
      downPayment: down,
      annualRatePercent: data.offer.annual_rent_rate,
      tenureMonths: tenure,
    });
  }, [data, downPct, tenure]);

  if (!token) return <Navigate to="/vehicles" replace />;

  const loginUrl = `/auth/login?returnUrl=${encodeURIComponent(`/quotes/${token}`)}`;

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <DocumentMeta title={t('meta.quoteTitle')} />
      <MarketplaceNav variant="solid" />
      <div className="dm-flow-page">
        {isLoading && <p>{t('vehicles.loading')}</p>}
        {error && <p style={{ color: 'var(--dm-danger)' }}>{(error as Error).message}</p>}

        {data?.gate === 'notFound' && (
          <>
            <h1>Offer not found</h1>
            <p style={{ color: 'var(--dm-slate-600)' }}>This link is invalid. Ask your dealer for a new one.</p>
            <Link to="/vehicles">{t('detail.back')}</Link>
          </>
        )}

        {data && data.gate !== 'notFound' && data.gate !== 'active' && (
          <>
            <h1>Special offer unavailable</h1>
            {data.gate === 'requiresAuth' && (
              <>
                <p style={{ color: 'var(--dm-slate-600)' }}>
                  Sign in with the email your dealer used for this offer ({data.customerEmailMasked}) to see your
                  special price.
                </p>
                <Link className="dm-btn-cta" to={loginUrl} style={{ display: 'inline-block', marginTop: 16 }}>
                  Sign in to continue
                </Link>
                <p style={{ marginTop: 16 }}>
                  No account? <Link to={`/auth/register?returnUrl=${encodeURIComponent(`/quotes/${token}`)}`}>Create one</Link>
                </p>
              </>
            )}
            {data.gate === 'wrongEmail' && (
              <>
                <p style={{ color: 'var(--dm-slate-600)' }}>
                  This offer is for {data.customerEmailMasked}. You are signed in as {user?.email}.
                </p>
                <button
                  type="button"
                  className="dm-btn-ghost"
                  onClick={() => void signOut().then(() => navigate(loginUrl))}
                >
                  Sign out and use the correct account
                </button>
              </>
            )}
            {data.gate === 'expired' && (
              <p style={{ color: 'var(--dm-slate-600)' }}>This offer expired. Contact the dealer for a new link.</p>
            )}
            {data.gate === 'used' && (
              <p style={{ color: 'var(--dm-slate-600)' }}>This offer was already used for an application.</p>
            )}
            {data.gate === 'revoked' && (
              <p style={{ color: 'var(--dm-slate-600)' }}>The dealer cancelled this offer.</p>
            )}
          </>
        )}

        {data?.gate === 'active' && data.product && data.negotiatedPrice != null && data.offer && (
          <>
            <p style={{ color: 'var(--dm-steel)', fontWeight: 600, margin: '0 0 8px' }}>Dealer special price</p>
            <h1 style={{ margin: '0 0 8px' }}>
              {data.product.make} {data.product.model}
              {data.product.trim ? ` ${data.product.trim}` : ''} · {data.product.modelYear}
            </h1>
            {data.company && (
              <p style={{ color: 'var(--dm-slate-600)', margin: '0 0 20px' }}>From {data.company.name}</p>
            )}
            <div className="dm-flow-card" style={{ marginBottom: 24 }}>
              <p style={{ margin: '0 0 4px', fontSize: 14, color: 'var(--dm-slate-600)' }}>Your price</p>
              <p style={{ margin: '0 0 12px', fontSize: 'clamp(1.35rem, 4vw, 1.75rem)', fontWeight: 700 }}>
                <MoneyText>{formatQar(data.negotiatedPrice, false, locale)}</MoneyText>
              </p>
              {data.product.publicListPrice > data.negotiatedPrice && (
                <p style={{ margin: 0, fontSize: 14, color: 'var(--dm-slate-600)' }}>
                  Public list price: {formatQar(data.product.publicListPrice, false, locale)}
                </p>
              )}
              <p style={{ margin: '12px 0 0', fontSize: 13, color: 'var(--dm-slate-600)' }}>
                Valid until {new Date(data.expiresAt!).toLocaleString(locale === 'ar' ? 'ar-QA' : 'en-QA')}
              </p>
            </div>
            <label className="dm-flow-field">
              {t('detail.tenure')}
              <select
                value={tenure}
                onChange={(e) => setTenure(Number(e.target.value))}
              >
                {(data.offer.tenure_options || [12, 24, 36, 48, 60]).map((mo) => (
                  <option key={mo} value={mo}>
                    {mo}
                  </option>
                ))}
              </select>
            </label>
            <label className="dm-flow-field">
              {t('detail.downPayment')} (%)
              <input
                type="number"
                min={data.offer.min_down_payment_pct}
                max={80}
                value={downPct}
                onChange={(e) => setDownPct(Number(e.target.value))}
              />
            </label>
            <p style={{ fontSize: 14, marginBottom: 24 }}>
              {t('detail.estMonthly')}: <MoneyText>{formatQar(Math.round(monthly), true, locale)}</MoneyText>
            </p>
            <button
              type="button"
              className="dm-btn-cta"
              onClick={() =>
                navigate(
                  `/app/applications/new?product=${data.product!.slug}&quote=${token}&tenure=${tenure}&downPct=${downPct}`,
                )
              }
            >
              {t('detail.apply')}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function ApplicationsListPage() {
  const { t } = useTranslation();
  const locale = getAppLocale();
  const { data, isLoading } = useQuery({
    queryKey: ['my-apps'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          status: string;
          createdAt: string;
          product: { make: string; model: string; modelYear: number; slug: string };
        }>
      >('/api/applications/mine'),
  });

  function statusVariant(status: string) {
    if (status === 'active' || status === 'completed') return 'approved';
    if (status === 'rejected' || status === 'submission_cancelled') return 'rejected';
    if (status === 'resubmission_required' || status === 'draft') return 'action';
    return 'pending';
  }

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <MarketplaceNav variant="solid" />
      <div style={{ padding: '24px var(--blox-page-gutter, 16px)', maxWidth: 800, margin: '0 auto' }}>
        <h1 style={{ fontFamily: 'var(--dm-font-display)' }}>{t('application.title')}</h1>
        {isLoading && <p>{t('vehicles.loading')}</p>}
        {!isLoading && !data?.length && (
          <p style={{ color: 'var(--dm-slate-600)' }}>
            {t('application.empty')}{' '}
            <Link to="/vehicles">{t('application.browse')}</Link>
          </p>
        )}
        <ul className="dm-app-list" style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 12 }}>
          {data?.map((a) => (
            <li key={a.id}>
              <Link to={`/app/applications/${a.id}`} className="dm-app-list__item">
                <div>
                  <strong>
                    {a.product.make} {a.product.model}
                    {a.product.modelYear ? ` · ${a.product.modelYear}` : ''}
                  </strong>
                  <div style={{ fontSize: 13, color: 'var(--dm-slate-600)', marginTop: 4 }}>
                    {new Date(a.createdAt).toLocaleDateString(locale === 'ar' ? 'ar-QA' : 'en-QA')}
                  </div>
                </div>
                <span className={`dm-status-pill dm-status-pill--${statusVariant(a.status)}`}>
                  {t(`application.status.${a.status}`, { defaultValue: a.status })}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
      <style>{`
        .dm-app-list__item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 16px 20px;
          background: var(--dm-surface);
          border: 1px solid var(--dm-slate-200);
          border-radius: 12px;
          text-decoration: none;
          color: inherit;
        }
        .dm-app-list__item:hover { border-color: var(--dm-steel); }
        .dm-status-pill {
          display: inline-block;
          padding: 6px 12px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 600;
          white-space: nowrap;
        }
        .dm-status-pill--approved { background: var(--dm-success-soft); color: var(--dm-success); }
        .dm-status-pill--pending { background: var(--dm-steel-soft); color: var(--dm-ink); }
        .dm-status-pill--rejected { background: var(--dm-danger-soft); color: var(--dm-danger); }
      `}</style>
    </div>
  );
}

function ApplicationDetailPage() {
  const { id } = useParams();
  const { t } = useTranslation();
  const { data, isLoading } = useQuery({
    queryKey: ['app', id],
    queryFn: () =>
      apiFetch<{
        id: string;
        status: string;
        createdAt: string;
        submittedAt?: string | null;
        pricingSnapshot?: Record<string, unknown>;
        rejectionReason?: string | null;
        resubmissionComment?: string | null;
        product?: { make?: string; model?: string; slug?: string; modelYear?: number };
        documents?: Array<{ id: string; category: string; mimeType?: string | null; createdAt: string }>;
        contractGenerated?: boolean;
        paymentSchedules?: Array<{
          id: string;
          sequence: number;
          dueDate: string;
          amount: string | number;
          status: string;
        }>;
      }>(`/api/applications/${id}`),
    enabled: !!id,
  });

  return (
    <div style={{ background: 'var(--dm-canvas)', minHeight: '100vh' }}>
      <MarketplaceNav variant="solid" />
      <div style={{ padding: '24px var(--blox-page-gutter, 16px)', maxWidth: 800, margin: '0 auto' }}>
        <p style={{ margin: '0 0 16px' }}>
          <Link to="/app/applications">← {t('application.title')}</Link>
        </p>
        {isLoading && <p>{t('vehicles.loading')}</p>}
        {data && <ApplicationDetailPanel app={data} />}
      </div>
    </div>
  );
}

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/vehicles" replace />} />
      <Route path="/vehicles" element={<VehiclesPage />} />
      <Route path="/vehicles/:slug" element={<VehicleDetailPage />} />
      <Route path="/dealers" element={<DealersDirectoryPage />} />
      <Route path="/dealers/:code" element={<DealerShowroomPage />} />
      <Route path="/compare" element={<ComparePage />} />
      <Route path="/help" element={<HelpPage />} />
      <Route path="/quotes/:token" element={<QuotePage />} />
      <Route
        path="/auth/login"
        element={
          <GuestGuard>
            <LoginPage
              portalLabel="Customer marketplace"
              homePath="/app/dashboard"
              allowSignUp
              showMarketplaceLink
            />
          </GuestGuard>
        }
      />
      <Route
        path="/auth/register"
        element={
          <GuestGuard>
            <RegisterPage homePath="/app/dashboard" />
          </GuestGuard>
        }
      />
      <Route path="/app/dashboard" element={<AuthGuard allowedRole="customer" reasonParam="not_customer"><CustomerDashboardPage /></AuthGuard>} />
      <Route path="/app/applications" element={<AuthGuard allowedRole="customer" reasonParam="not_customer"><ApplicationsListPage /></AuthGuard>} />
      <Route path="/app/applications/new" element={<AuthGuard allowedRole="customer" reasonParam="not_customer"><ApplyWizardPage /></AuthGuard>} />
      <Route path="/app/applications/:id" element={<AuthGuard allowedRole="customer" reasonParam="not_customer"><ApplicationDetailPage /></AuthGuard>} />
      <Route path="*" element={<Navigate to="/vehicles" replace />} />
    </Routes>
  );
}
