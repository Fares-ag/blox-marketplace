import { StrictMode, useEffect, useState, FormEvent } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes, Link, useParams, useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider, useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ThemeProvider, CssBaseline } from '@mui/material';
import {
  AuthGuard,
  LoginPage,
  BloxShell,
  bloxThemeWithBrand,
  useAuthStore,
  apiFetch,
  formatQar,
  MoneyText,
  estimateMonthlyPayment,
  OpsPageHeader,
  OpsStatCard,
  OpsStatusPill,
  OpsEmptyState,
  OpsPanel,
  OpsDataTable,
  ScrollToTop,
  type BloxNavItem,
  type OpsPillVariant,
} from '@drivemarket/shared';

const queryClient = new QueryClient();

const nav: BloxNavItem[] = [
  { to: '/', label: 'Dashboard', icon: 'home' },
  { to: '/inventory', label: 'Inventory', icon: 'inventory' },
  { to: '/quotes', label: 'Quotes', icon: 'quotes' },
  { to: '/applications', label: 'Applications', icon: 'apps' },
  { to: '/company', label: 'Company', icon: 'company' },
];

function statusVariant(status: string): OpsPillVariant {
  if (status === 'published' || status === 'active' || status === 'approved') return 'published';
  if (status === 'draft') return 'draft';
  if (status === 'reserved') return 'reserved';
  if (status === 'sold' || status === 'rejected') return 'sold';
  return 'pending';
}

function Dashboard() {
  const { data } = useQuery({
    queryKey: ['dealer-inventory'],
    queryFn: () => apiFetch<Array<{ listingStatus: string }>>('/api/dealer/inventory'),
  });
  const counts = {
    draft: data?.filter((p) => p.listingStatus === 'draft').length ?? 0,
    published: data?.filter((p) => p.listingStatus === 'published').length ?? 0,
    reserved: data?.filter((p) => p.listingStatus === 'reserved').length ?? 0,
    sold: data?.filter((p) => p.listingStatus === 'sold').length ?? 0,
  };
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Dealer dashboard"
        subtitle="Inventory snapshot for your showroom"
        actions={
          <Link className="blox-btn blox-btn--primary" to="/inventory/new">
            Create listing
          </Link>
        }
      />
      <div className="blox-stat-grid">
        <OpsStatCard label="Draft" value={String(counts.draft)} />
        <OpsStatCard label="Published" value={String(counts.published)} />
        <OpsStatCard label="Reserved" value={String(counts.reserved)} />
        <OpsStatCard label="Sold" value={String(counts.sold)} />
      </div>
    </div>
  );
}

function InventoryList() {
  const { data, error } = useQuery({
    queryKey: ['dealer-inventory'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          make: string;
          model: string;
          modelYear: number;
          price: string | number;
          listingStatus: string;
        }>
      >('/api/dealer/inventory'),
  });
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Inventory"
        subtitle="Manage listings for your dealership"
        actions={
          <Link className="blox-btn blox-btn--primary" to="/inventory/new">
            New listing
          </Link>
        }
      />
      {error && <p style={{ color: 'var(--blox-danger)' }}>{(error as Error).message}</p>}
      <OpsDataTable
        columns={['Vehicle', 'Year', 'Price', 'Status']}
        empty={<OpsEmptyState title="No listings yet" body="Create a listing to publish inventory to the marketplace." />}
        rows={(data ?? []).map((p) => [
          <Link key="v" to={`/inventory/${p.id}`}>
            {p.make} {p.model}
          </Link>,
          String(p.modelYear),
          <span key="p" className="blox-money">
            <MoneyText>{formatQar(Number(p.price))}</MoneyText>
          </span>,
          <OpsStatusPill key="s" label={p.listingStatus} variant={statusVariant(p.listingStatus)} />,
        ])}
      />
    </div>
  );
}

function InventoryEditor() {
  const { id } = useParams();
  const isNew = !id || id === 'new';
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [trim, setTrim] = useState('');
  const [modelYear, setModelYear] = useState(2024);
  const [price, setPrice] = useState(100000);
  const [description, setDescription] = useState('');
  const [condition, setCondition] = useState<'new' | 'used'>('used');
  const [engine, setEngine] = useState('');
  const [transmission, setTransmission] = useState<'automatic' | 'manual' | ''>('');
  const [cylinders, setCylinders] = useState<number | ''>('');
  const [drivetrain, setDrivetrain] = useState<'fwd' | 'rwd' | 'awd' | 'four_wd' | ''>('');
  const [bodyType, setBodyType] = useState<'sedan' | 'suv' | 'coupe' | 'hatchback' | 'pickup' | 'van' | 'other' | ''>('');
  const [color, setColor] = useState('');
  const [mileage, setMileage] = useState<number | ''>('');
  const [warrantyMonths, setWarrantyMonths] = useState<number | ''>('');
  const [warrantyNotes, setWarrantyNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [quoteEmail, setQuoteEmail] = useState('');
  const [quotePrice, setQuotePrice] = useState<number>(80000);
  const [quoteExpires, setQuoteExpires] = useState('');
  const [createdQuoteUrl, setCreatedQuoteUrl] = useState<string | null>(null);

  const existing = useQuery({
    queryKey: ['dealer-inventory'],
    queryFn: () => apiFetch<Array<Record<string, unknown>>>('/api/dealer/inventory'),
    enabled: !isNew,
  });

  useEffect(() => {
    if (isNew || !existing.data) return;
    const row = existing.data.find((p) => p.id === id);
    if (!row) return;
    setMake(String(row.make ?? ''));
    setModel(String(row.model ?? ''));
    setTrim(String(row.trim ?? ''));
    setModelYear(Number(row.modelYear ?? 2024));
    setPrice(Number(row.price ?? 0));
    setDescription(String(row.description ?? ''));
    setCondition((row.condition as 'new' | 'used') ?? 'used');
    setEngine(String(row.engine ?? ''));
    setTransmission((row.transmission as 'automatic' | 'manual') ?? '');
    setCylinders(row.cylinders != null ? Number(row.cylinders) : '');
    setDrivetrain((row.drivetrain as typeof drivetrain) ?? '');
    setBodyType((row.bodyType as typeof bodyType) ?? '');
    setColor(String(row.color ?? ''));
    setMileage(row.mileage != null ? Number(row.mileage) : '');
    setWarrantyMonths(row.warrantyMonths != null ? Number(row.warrantyMonths) : '');
    setWarrantyNotes(String(row.warrantyNotes ?? ''));
    setQuotePrice(Math.round(Number(row.price ?? 0) * 0.9));
  }, [existing.data, id, isNew]);

  useEffect(() => {
    if (quoteExpires) return;
    const d = new Date();
    d.setDate(d.getDate() + 7);
    const pad = (n: number) => String(n).padStart(2, '0');
    setQuoteExpires(
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`,
    );
  }, [quoteExpires]);

  const currentRow = existing.data?.find((p) => p.id === id);
  const isPublished = currentRow?.listingStatus === 'published';
  const isFinanceEligible = currentRow?.financeEligible !== false;

  const createQuote = useMutation({
    mutationFn: () =>
      apiFetch<{ url: string }>('/api/dealer/quotes', {
        method: 'POST',
        body: JSON.stringify({
          productId: id,
          customerEmail: quoteEmail.trim(),
          negotiatedPrice: quotePrice,
          expiresAt: new Date(quoteExpires).toISOString(),
        }),
      }),
    onSuccess: (row) => {
      setCreatedQuoteUrl(row.url);
      void qc.invalidateQueries({ queryKey: ['dealer-quotes'] });
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const save = useMutation({
    mutationFn: async () => {
      const body = {
        make,
        model,
        trim: trim || undefined,
        modelYear,
        price,
        description,
        condition,
        engine: engine || undefined,
        transmission: transmission || undefined,
        cylinders: cylinders === '' ? undefined : Number(cylinders),
        drivetrain: drivetrain || undefined,
        bodyType: bodyType || undefined,
        color: color || undefined,
        mileage: mileage === '' ? undefined : Number(mileage),
        warrantyMonths: warrantyMonths === '' ? undefined : Number(warrantyMonths),
        warrantyNotes: warrantyNotes || undefined,
      };
      if (isNew) {
        return apiFetch<{ id: string }>('/api/dealer/inventory', {
          method: 'POST',
          body: JSON.stringify(body),
        });
      }
      await apiFetch(`/api/dealer/inventory/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(body),
      });
      return { id: id as string };
    },
    onSuccess: (row: { id: string }) => {
      void qc.invalidateQueries({ queryKey: ['dealer-inventory'] });
      navigate(`/inventory/${row.id}`);
    },
    onError: (e: Error) => setError(e.message),
  });

  const publish = useMutation({
    mutationFn: () => apiFetch(`/api/dealer/inventory/${id}/publish`, { method: 'POST' }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['dealer-inventory'] }),
    onError: (e: Error) => setError(e.message),
  });

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || isNew || !id) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      await apiFetch(`/api/dealer/inventory/${id}/images`, { method: 'POST', body: fd });
      void qc.invalidateQueries({ queryKey: ['dealer-inventory'] });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    }
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    save.mutate();
  }

  return (
    <div className="blox-page">
      <OpsPageHeader
        title={isNew ? 'New listing' : 'Edit listing'}
        subtitle="Vehicle details and financing eligibility"
      />
      <OpsPanel title="Vehicle details">
        <form onSubmit={onSubmit} className="blox-form blox-form--2col">
          <label>
            Make
            <input required value={make} onChange={(e) => setMake(e.target.value)} />
          </label>
          <label>
            Model
            <input required value={model} onChange={(e) => setModel(e.target.value)} />
          </label>
          <label>
            Trim
            <input value={trim} onChange={(e) => setTrim(e.target.value)} />
          </label>
          <label>
            Year
            <input type="number" required value={modelYear} onChange={(e) => setModelYear(Number(e.target.value))} />
          </label>
          <label>
            Condition
            <select value={condition} onChange={(e) => setCondition(e.target.value as 'new' | 'used')}>
              <option value="used">Used</option>
              <option value="new">New</option>
            </select>
          </label>
          <label>
            Transmission
            <select value={transmission} onChange={(e) => setTransmission(e.target.value as typeof transmission)}>
              <option value="">—</option>
              <option value="automatic">Automatic</option>
              <option value="manual">Manual</option>
            </select>
          </label>
          <label>
            Cylinders
            <input type="number" value={cylinders} onChange={(e) => setCylinders(e.target.value ? Number(e.target.value) : '')} />
          </label>
          <label>
            Drivetrain
            <select value={drivetrain} onChange={(e) => setDrivetrain(e.target.value as typeof drivetrain)}>
              <option value="">—</option>
              <option value="fwd">FWD</option>
              <option value="rwd">RWD</option>
              <option value="awd">AWD</option>
              <option value="four_wd">4WD</option>
            </select>
          </label>
          <label>
            Body type
            <select value={bodyType} onChange={(e) => setBodyType(e.target.value as typeof bodyType)}>
              <option value="">—</option>
              <option value="sedan">Sedan</option>
              <option value="suv">SUV</option>
              <option value="coupe">Coupe</option>
              <option value="hatchback">Hatchback</option>
              <option value="pickup">Pickup</option>
              <option value="van">Van</option>
              <option value="other">Other</option>
            </select>
          </label>
          <label>
            Engine
            <input value={engine} onChange={(e) => setEngine(e.target.value)} />
          </label>
          <label>
            Color
            <input value={color} onChange={(e) => setColor(e.target.value)} />
          </label>
          <label>
            Mileage (km)
            <input type="number" value={mileage} onChange={(e) => setMileage(e.target.value ? Number(e.target.value) : '')} />
          </label>
          <label>
            Warranty months
            <input type="number" value={warrantyMonths} onChange={(e) => setWarrantyMonths(e.target.value ? Number(e.target.value) : '')} />
          </label>
          <label>
            Warranty notes
            <input value={warrantyNotes} onChange={(e) => setWarrantyNotes(e.target.value)} />
          </label>
          <label>
            Price (QAR)
            <input type="number" required value={price} onChange={(e) => setPrice(Number(e.target.value))} />
          </label>
          <label className="blox-form__full">
            Description
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} />
          </label>
          {error && <p className="blox-form__full" style={{ color: 'var(--blox-danger)', margin: 0 }}>{error}</p>}
          <button type="submit" className="blox-btn blox-btn--primary blox-form__full">
            Save
          </button>
        </form>
      </OpsPanel>
      {!isNew && (
        <div className="blox-section-grid blox-section-grid--2">
          <OpsPanel title="Publish & media">
            <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
              Upload image
              <input type="file" accept="image/*" onChange={onUpload} />
            </label>
            <button type="button" className="blox-btn blox-btn--secondary" style={{ marginTop: 12 }} onClick={() => publish.mutate()}>
              Publish
            </button>
          </OpsPanel>
          {isPublished && isFinanceEligible && (
            <OpsPanel title="Special price link">
              <p className="blox-page-header__subtitle" style={{ margin: '0 0 12px' }}>
                One-time, email-bound link. Public listing stays at list price.
              </p>
              <form
                className="blox-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  setCreatedQuoteUrl(null);
                  createQuote.mutate();
                }}
              >
                <label>
                  Customer email
                  <input
                    type="email"
                    required
                    value={quoteEmail}
                    onChange={(e) => setQuoteEmail(e.target.value)}
                    placeholder="customer@example.com"
                  />
                </label>
                <label>
                  Negotiated price (QAR)
                  <input
                    type="number"
                    required
                    min={1}
                    max={price}
                    value={quotePrice}
                    onChange={(e) => setQuotePrice(Number(e.target.value))}
                  />
                </label>
                <label>
                  Expires
                  <input
                    type="datetime-local"
                    required
                    value={quoteExpires}
                    onChange={(e) => setQuoteExpires(e.target.value)}
                  />
                </label>
                <button type="submit" className="blox-btn blox-btn--primary" disabled={createQuote.isPending}>
                  {createQuote.isPending ? 'Creating…' : 'Generate link'}
                </button>
              </form>
              {createdQuoteUrl && (
                <div style={{ marginTop: 14, padding: 12, background: 'var(--blox-emerald-soft)', borderRadius: 8 }}>
                  <p style={{ margin: '0 0 8px', fontSize: '0.8125rem', fontWeight: 600 }}>Share this link</p>
                  <code style={{ display: 'block', wordBreak: 'break-all', fontSize: '0.75rem' }}>{createdQuoteUrl}</code>
                  <button
                    type="button"
                    className="blox-btn blox-btn--secondary"
                    style={{ marginTop: 10 }}
                    onClick={() => void navigator.clipboard.writeText(createdQuoteUrl)}
                  >
                    Copy link
                  </button>
                </div>
              )}
            </OpsPanel>
          )}
        </div>
      )}
    </div>
  );
}

function QuotesPage() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ['dealer-quotes'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          url: string;
          customerEmail: string;
          negotiatedPrice: number;
          listPriceSnapshot: number;
          expiresAt: string;
          status: string;
          product: { make: string; model: string; modelYear: number };
        }>
      >('/api/dealer/quotes'),
  });

  const revoke = useMutation({
    mutationFn: (quoteId: string) =>
      apiFetch(`/api/dealer/quotes/${quoteId}/revoke`, { method: 'POST' }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['dealer-quotes'] }),
  });

  return (
    <div className="blox-page">
      <OpsPageHeader title="Quotes" subtitle="Private special-price links sent to customers" />
      <OpsDataTable
        columns={['Vehicle', 'Customer', 'Price', 'Expires', 'Status', '']}
        empty={<OpsEmptyState title="No quotes yet" body="Create one from a published listing." />}
        rows={(data ?? []).map((q) => [
          `${q.product.make} ${q.product.model} ${q.product.modelYear}`,
          q.customerEmail,
          <span key="price" className="blox-money">
            <MoneyText>{formatQar(q.negotiatedPrice, false)}</MoneyText>
          </span>,
          new Date(q.expiresAt).toLocaleString(),
          <OpsStatusPill
            key="st"
            label={q.status}
            variant={q.status === 'active' ? 'published' : q.status === 'used' ? 'approved' : 'draft'}
          />,
          <div key="act" style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button
              type="button"
              className="blox-btn blox-btn--ghost"
              onClick={() => void navigator.clipboard.writeText(q.url)}
            >
              Copy
            </button>
            {q.status === 'active' && (
              <button
                type="button"
                className="blox-btn blox-btn--danger"
                onClick={() => revoke.mutate(q.id)}
                disabled={revoke.isPending}
              >
                Revoke
              </button>
            )}
          </div>,
        ])}
      />
    </div>
  );
}

function Applications() {
  const { data } = useQuery({
    queryKey: ['dealer-apps'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          status: string;
          product: { make: string; model: string };
          customer: { name: string; email: string };
        }>
      >('/api/dealer/applications'),
  });
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Applications"
        subtitle="Walk-in and online leads on your stock"
        actions={
          <Link className="blox-btn blox-btn--primary" to="/applications/walk-in">
            Walk-in application
          </Link>
        }
      />
      <OpsDataTable
        columns={['Vehicle', 'Customer', 'Email', 'Status']}
        empty={<OpsEmptyState title="No applications yet" body="Leads appear here when customers apply on your stock." />}
        rows={(data ?? []).map((a) => [
          `${a.product.make} ${a.product.model}`,
          a.customer.name,
          a.customer.email,
          <OpsStatusPill key="s" label={a.status} variant={statusVariant(a.status)} />,
        ])}
      />
    </div>
  );
}

function WalkInApplication() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const inventory = useQuery({
    queryKey: ['dealer-inventory'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          make: string;
          model: string;
          modelYear: number;
          price: string | number;
          listingStatus: string;
          financeEligible?: boolean;
        }>
      >('/api/dealer/inventory'),
  });
  const partners = useQuery({
    queryKey: ['finance-partners'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          name: string;
          crmAdapter: string;
          offers: Array<{
            id: string;
            name: string;
            annualRentRate: string | number;
            minDownPaymentPct: string | number;
            tenureOptions: number[];
          }>;
        }>
      >('/api/finance-partners'),
  });

  const [productId, setProductId] = useState('');
  const [financePartnerId, setFinancePartnerId] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [qid, setQid] = useState('');
  const [employment, setEmployment] = useState('');
  const [income, setIncome] = useState('');
  const [tenure, setTenure] = useState(36);
  const [downPct, setDownPct] = useState(10);
  const [error, setError] = useState<string | null>(null);

  const published = (inventory.data ?? []).filter(
    (p) => p.listingStatus === 'published' && p.financeEligible !== false,
  );
  const selectedProduct = published.find((p) => p.id === productId);
  const selectedPartner = partners.data?.find((p) => p.id === financePartnerId);
  const partnerOffer = selectedPartner?.offers[0];

  useEffect(() => {
    if (!published.length || productId) return;
    setProductId(published[0].id);
  }, [published, productId]);

  useEffect(() => {
    if (!partners.data?.length || financePartnerId) return;
    setFinancePartnerId(partners.data[0].id);
  }, [partners.data, financePartnerId]);

  useEffect(() => {
    if (!partnerOffer) return;
    const minDown = Number(partnerOffer.minDownPaymentPct ?? 10);
    setDownPct((prev) => Math.max(prev, minDown));
    const options = (partnerOffer.tenureOptions ?? []).map(Number);
    if (!options.includes(tenure)) {
      setTenure(options.includes(36) ? 36 : options[0]);
    }
  }, [partnerOffer, tenure]);

  const monthlyPreview =
    selectedProduct && partnerOffer
      ? estimateMonthlyPayment({
          price: Number(selectedProduct.price),
          downPayment: (Number(selectedProduct.price) * downPct) / 100,
          annualRatePercent: Number(partnerOffer.annualRentRate),
          tenureMonths: tenure,
        })
      : 0;

  const createWalkIn = useMutation({
    mutationFn: () => {
      if (!selectedProduct || !partnerOffer || !financePartnerId) {
        throw new Error('validation_failed');
      }
      const listPrice = Number(selectedProduct.price);
      const down = (listPrice * downPct) / 100;
      return apiFetch<{ id: string }>('/api/dealer/applications', {
        method: 'POST',
        body: JSON.stringify({
          productId: selectedProduct.id,
          offerId: partnerOffer.id,
          financePartnerId,
          customerEmail: customerEmail.trim(),
          customerSnapshot: {
            full_name: fullName,
            phone,
            qid,
            employment,
            income: Number(income) || 0,
          },
          pricingSnapshot: {
            list_price: listPrice,
            down_payment: down,
            down_payment_pct: downPct,
            tenor: tenure,
            rate: Number(partnerOffer.annualRentRate),
            monthly: Math.round(monthlyPreview),
          },
        }),
      });
    },
    onSuccess: (app) => {
      void qc.invalidateQueries({ queryKey: ['dealer-apps'] });
      navigate('/applications');
    },
    onError: (e: Error) => setError(e.message),
  });

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createWalkIn.mutate();
  }

  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Walk-in application"
        subtitle="Apply on behalf of a showroom customer and route to their finance partner"
        actions={
          <Link className="blox-btn blox-btn--ghost" to="/applications">
            Back
          </Link>
        }
      />
      <OpsPanel title="Customer & vehicle">
        <form onSubmit={onSubmit} style={{ display: 'grid', gap: 14, maxWidth: 520 }}>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Vehicle
            <select value={productId} onChange={(e) => setProductId(e.target.value)} required>
              {published.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.make} {p.model} {p.modelYear} · QAR {Number(p.price).toLocaleString()}
                </option>
              ))}
            </select>
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Finance company
            <select
              value={financePartnerId}
              onChange={(e) => setFinancePartnerId(e.target.value)}
              required
            >
              {(partners.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                  {p.crmAdapter === 'zoho' ? ' · Zoho CRM' : ''}
                </option>
              ))}
            </select>
          </label>
          {partnerOffer && (
            <p style={{ margin: 0, fontSize: '0.8125rem', color: 'var(--blox-slate)' }}>
              {partnerOffer.name} · est. monthly{' '}
              <MoneyText>{formatQar(Math.round(monthlyPreview), true)}</MoneyText>
            </p>
          )}
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Tenure (months)
            <select value={tenure} onChange={(e) => setTenure(Number(e.target.value))}>
              {(partnerOffer?.tenureOptions ?? [12, 24, 36, 48, 60]).map((mo) => (
                <option key={mo} value={mo}>
                  {mo}
                </option>
              ))}
            </select>
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Down payment %
            <input
              type="number"
              min={partnerOffer ? Number(partnerOffer.minDownPaymentPct) : 10}
              max={80}
              value={downPct}
              onChange={(e) => setDownPct(Number(e.target.value))}
            />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Customer email
            <input value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} required />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Full name
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Phone
            <input value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            QID
            <input value={qid} onChange={(e) => setQid(e.target.value)} required />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Employment
            <input value={employment} onChange={(e) => setEmployment(e.target.value)} />
          </label>
          <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600 }}>
            Monthly income (QAR)
            <input value={income} onChange={(e) => setIncome(e.target.value)} />
          </label>
          {error && <p style={{ margin: 0, color: 'var(--blox-danger)' }}>{error}</p>}
          <button type="submit" className="blox-btn blox-btn--primary" disabled={createWalkIn.isPending}>
            {createWalkIn.isPending ? 'Submitting…' : 'Submit walk-in application'}
          </button>
        </form>
      </OpsPanel>
    </div>
  );
}

function CompanyPage() {
  const { data } = useQuery({
    queryKey: ['company-mine'],
    queryFn: () =>
      apiFetch<{
        name?: string;
        code?: string | null;
        status?: string;
        contactEmail?: string | null;
        contactPhone?: string | null;
        address?: string | null;
      } | null>('/api/companies/mine'),
  });
  return (
    <div className="blox-page">
      <OpsPageHeader title="Company" subtitle="Your dealership profile" />
      {!data ? (
        <OpsEmptyState title="No company profile" />
      ) : (
        <OpsPanel title={data.name ?? 'Dealership'}>
          <div className="blox-stat-grid">
            <div>
              <p className="blox-stat-card__label">Code</p>
              <p style={{ margin: 0, fontWeight: 600 }}>{data.code ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Status</p>
              <OpsStatusPill label={data.status ?? '—'} variant={data.status === 'active' ? 'active' : 'draft'} />
            </div>
            <div>
              <p className="blox-stat-card__label">Email</p>
              <p style={{ margin: 0 }}>{data.contactEmail ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Phone</p>
              <p style={{ margin: 0 }}>{data.contactPhone ?? '—'}</p>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <p className="blox-stat-card__label">Address</p>
              <p style={{ margin: 0 }}>{data.address ?? '—'}</p>
            </div>
          </div>
        </OpsPanel>
      )}
    </div>
  );
}

function App() {
  const init = useAuthStore((s) => s.init);
  useEffect(() => {
    void init();
  }, [init]);

  return (
    <Routes>
      <Route path="/auth/login" element={<LoginPage portalLabel="Blox Dealer" homePath="/" />} />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="dealer_agent" reasonParam="not_dealer">
            <BloxShell title="Dealer" nav={nav}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/inventory" element={<InventoryList />} />
                <Route path="/inventory/new" element={<InventoryEditor />} />
                <Route path="/inventory/:id" element={<InventoryEditor />} />
                <Route path="/quotes" element={<QuotesPage />} />
                <Route path="/applications" element={<Applications />} />
                <Route path="/applications/walk-in" element={<WalkInApplication />} />
                <Route path="/company" element={<CompanyPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={bloxThemeWithBrand}>
        <CssBaseline />
        <BrowserRouter>
          <ScrollToTop />
          <App />
        </BrowserRouter>
      </ThemeProvider>
    </QueryClientProvider>
  </StrictMode>,
);
