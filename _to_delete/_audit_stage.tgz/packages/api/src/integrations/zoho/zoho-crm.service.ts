import { Injectable, Logger } from '@nestjs/common';

import type { ApplicationDocument } from '@prisma/client';

import { PrismaService } from '../../prisma/prisma.service';

import { StorageService } from '../../storage/storage.service';

import { ActivityService } from '../../common/activity.service';

import { ZohoAuthService } from './zoho-auth.service';

import { ZohoConfig } from './zoho-config';

import { mapApplicationToZohoLead, type ApplicationForZoho } from './zoho-lead.mapper';



type ZohoLeadResponse = {

  data?: Array<{

    code: string;

    details?: { id?: string };

    message?: string;

    status?: string;

  }>;

};



type ZohoAttachmentListResponse = {

  data?: Array<{ id?: string; File_Name?: string; file_name?: string }>;

};



@Injectable()

export class ZohoCrmService {

  private readonly logger = new Logger(ZohoCrmService.name);



  constructor(

    private readonly prisma: PrismaService,

    private readonly auth: ZohoAuthService,

    private readonly config: ZohoConfig,

    private readonly activity: ActivityService,

    private readonly storage: StorageService,

  ) {}



  async syncApplicationToZoho(

    applicationId: string,

    actorUserId?: string,

  ): Promise<{ zohoLeadId: string | null; error?: string; documentsUploaded?: number }> {

    if (!this.config.enabled) {

      return { zohoLeadId: null, error: 'zoho_not_configured' };

    }



    const app = await this.prisma.application.findUnique({

      where: { id: applicationId },

      include: {

        product: true,

        company: { select: { id: true, name: true } },

        offer: true,

        financePartner: true,

        documents: true,

      },

    });



    if (!app) return { zohoLeadId: null, error: 'application_not_found' };

    if (app.financePartner?.crmAdapter !== 'zoho') {

      return { zohoLeadId: null, error: 'partner_not_zoho' };

    }



    try {

      const leadPayload = mapApplicationToZohoLead(

        app as ApplicationForZoho,

        this.config.requestSubmittedTo,

      );



      let zohoLeadId = app.zohoLeadId;



      if (zohoLeadId) {

        await this.updateLead(zohoLeadId, leadPayload);

      } else {

        const existingId = await this.findLeadIdByEmail(app.customerEmail);

        if (existingId) {

          zohoLeadId = existingId;

          await this.updateLead(existingId, leadPayload);

        } else {

          zohoLeadId = await this.createLead(leadPayload);

        }

      }



      const documentsUploaded = await this.syncDocuments(zohoLeadId, app.documents);



      await this.prisma.application.update({

        where: { id: applicationId },

        data: {

          zohoLeadId,

          zohoSyncedAt: new Date(),

          zohoSyncError: null,

        },

      });



      await this.activity.log({

        actorUserId,

        entityType: 'application',

        entityId: applicationId,

        action: 'crm_export',

        toValue: zohoLeadId ?? undefined,

        metadata: {

          provider: 'zoho',

          partnerCode: app.financePartner?.code,

          documentsUploaded,

        },

      });



      return { zohoLeadId, documentsUploaded };

    } catch (err) {

      const message = err instanceof Error ? err.message : 'zoho_sync_failed';

      this.logger.error(`Zoho sync failed for ${applicationId}: ${message}`);



      await this.prisma.application.update({

        where: { id: applicationId },

        data: { zohoSyncError: message.slice(0, 500) },

      });



      await this.activity.log({

        actorUserId,

        entityType: 'application',

        entityId: applicationId,

        action: 'crm_export_failed',

        toValue: message.slice(0, 200),

        metadata: { provider: 'zoho' },

      });



      return { zohoLeadId: null, error: message };

    }

  }



  private async createLead(payload: Record<string, unknown>): Promise<string> {

    const token = await this.auth.getAccessToken();

    const res = await fetch(`${this.config.apiDomain}/crm/v8/Leads`, {

      method: 'POST',

      headers: {

        Authorization: `Zoho-oauthtoken ${token}`,

        'Content-Type': 'application/json',

      },

      body: JSON.stringify({ data: [payload] }),

    });



    const body = (await res.json()) as ZohoLeadResponse;

    if (!res.ok) {

      throw new Error(JSON.stringify(body));

    }



    const row = body.data?.[0];

    if (row?.code !== 'SUCCESS' || !row.details?.id) {

      throw new Error(row?.message ?? JSON.stringify(body));

    }



    return row.details.id;

  }



  private async updateLead(id: string, payload: Record<string, unknown>): Promise<void> {

    const token = await this.auth.getAccessToken();

    const res = await fetch(`${this.config.apiDomain}/crm/v8/Leads/${id}`, {

      method: 'PUT',

      headers: {

        Authorization: `Zoho-oauthtoken ${token}`,

        'Content-Type': 'application/json',

      },

      body: JSON.stringify({ data: [payload] }),

    });



    const body = (await res.json()) as ZohoLeadResponse;

    if (!res.ok) {

      throw new Error(JSON.stringify(body));

    }



    const row = body.data?.[0];

    if (row?.code !== 'SUCCESS') {

      throw new Error(row?.message ?? JSON.stringify(body));

    }

  }



  private async findLeadIdByEmail(email: string): Promise<string | null> {

    const token = await this.auth.getAccessToken();

    const criteria = encodeURIComponent(`(Email:equals:${email})`);

    const res = await fetch(

      `${this.config.apiDomain}/crm/v8/Leads/search?criteria=${criteria}`,

      {

        headers: { Authorization: `Zoho-oauthtoken ${token}` },

      },

    );



    if (res.status === 204) return null;



    const body = (await res.json()) as { data?: Array<{ id: string }> };

    if (!res.ok) return null;



    return body.data?.[0]?.id ?? null;

  }



  private async syncDocuments(leadId: string, documents: ApplicationDocument[]): Promise<number> {

    if (documents.length === 0) return 0;



    const existingNames = await this.listAttachmentNames(leadId);

    let uploaded = 0;



    for (const doc of documents) {

      const originalName = doc.storagePath.split('/').pop() ?? `${doc.category}.pdf`;

      const fileName = `blox-${doc.category}-${originalName}`;

      if (existingNames.has(fileName)) continue;



      try {

        const { buffer, contentType } = await this.storage.readKyc(doc.storagePath);

        await this.uploadAttachment(leadId, fileName, buffer, contentType);

        existingNames.add(fileName);

        uploaded += 1;

      } catch (err) {

        const message = err instanceof Error ? err.message : 'attachment_upload_failed';

        this.logger.warn(`Zoho attachment upload failed (${doc.category}): ${message}`);

      }

    }



    return uploaded;

  }



  private async listAttachmentNames(leadId: string): Promise<Set<string>> {

    const token = await this.auth.getAccessToken();

    const res = await fetch(`${this.config.apiDomain}/crm/v8/Leads/${leadId}/Attachments`, {

      headers: { Authorization: `Zoho-oauthtoken ${token}` },

    });



    if (res.status === 204) return new Set();

    if (!res.ok) {

      const text = await res.text();

      this.logger.warn(`Zoho attachment list failed (${res.status}): ${text.slice(0, 200)}`);

      return new Set();

    }



    const body = (await res.json()) as ZohoAttachmentListResponse;

    const names = (body.data ?? [])

      .map((row) => row.File_Name ?? row.file_name ?? '')

      .filter(Boolean);

    return new Set(names);

  }



  private async uploadAttachment(

    leadId: string,

    fileName: string,

    buffer: Buffer,

    contentType: string,

  ): Promise<void> {

    const token = await this.auth.getAccessToken();

    const form = new FormData();

    form.append(

      'file',

      new Blob([new Uint8Array(buffer)], { type: contentType || 'application/octet-stream' }),

      fileName,

    );



    const res = await fetch(`${this.config.apiDomain}/crm/v8/Leads/${leadId}/Attachments`, {

      method: 'POST',

      headers: { Authorization: `Zoho-oauthtoken ${token}` },

      body: form,

    });



    const text = await res.text();

    if (!res.ok) {

      throw new Error(`attachment_upload_failed (${res.status}): ${text.slice(0, 300)}`);

    }



    let body: ZohoLeadResponse;

    try {

      body = JSON.parse(text) as ZohoLeadResponse;

    } catch {

      return;

    }



    const row = body.data?.[0];

    if (row && row.code !== 'SUCCESS') {

      throw new Error(row.message ?? text.slice(0, 300));

    }

  }

}


