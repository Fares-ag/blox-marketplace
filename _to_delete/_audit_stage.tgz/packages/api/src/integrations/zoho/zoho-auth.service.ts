import { Injectable, Logger } from '@nestjs/common';
import { ZohoConfig } from './zoho-config';

type TokenResponse = {
  access_token: string;
  api_domain?: string;
  expires_in?: number;
  error?: string;
};

@Injectable()
export class ZohoAuthService {
  private readonly logger = new Logger(ZohoAuthService.name);
  private cachedAccessToken: string | null = null;
  private tokenExpiresAt = 0;

  constructor(private readonly config: ZohoConfig) {}

  async getAccessToken(): Promise<string> {
    if (!this.config.enabled) {
      throw new Error('zoho_not_configured');
    }

    const now = Date.now();
    if (this.cachedAccessToken && now < this.tokenExpiresAt - 60_000) {
      return this.cachedAccessToken;
    }

    const url = new URL('/oauth/v2/token', this.config.accountsUrl);
    url.searchParams.set('grant_type', 'refresh_token');
    url.searchParams.set('client_id', this.config.clientId);
    url.searchParams.set('client_secret', this.config.clientSecret);
    url.searchParams.set('refresh_token', this.config.refreshToken);

    const res = await fetch(url.toString(), { method: 'POST' });
    const text = await res.text();
    let body: TokenResponse;
    try {
      body = JSON.parse(text) as TokenResponse;
    } catch {
      this.logger.error(`Zoho token refresh returned non-JSON (${res.status}): ${text.slice(0, 200)}`);
      throw new Error('zoho_token_refresh_invalid_response');
    }

    if (!res.ok || !body.access_token) {
      this.logger.error(`Zoho token refresh failed: ${JSON.stringify(body)}`);
      throw new Error(body.error ?? 'zoho_token_refresh_failed');
    }

    this.cachedAccessToken = body.access_token;
    this.tokenExpiresAt = now + (body.expires_in ?? 3600) * 1000;
    return body.access_token;
  }
}
