import { describe, expect, it } from 'vitest';

import { mapApplicationToZohoLead } from './zoho-lead.mapper';



describe('mapApplicationToZohoLead', () => {

  it('maps core customer and finance fields', () => {

    const payload = mapApplicationToZohoLead(

      {

        id: 'app_test_123',

        customerEmail: 'customer@example.com',

        customerSnapshot: {

          full_name: 'Ali Hassan',

          phone: '+974 5555 1234',

          qid: '28099887766',

          employment: 'Engineer',

          income: 15000,

        },

        pricingSnapshot: {

          list_price: 100000,

          down_payment: 10000,

          down_payment_pct: 10,

          tenor: 36,

          monthly: 3200,

        },

        leadSource: 'Blox Marketplace',

        agentUserId: null,

        product: {

          make: 'Toyota',

          model: 'Land Cruiser',

          modelYear: 2024,

          trim: 'GXR',

          slug: 'toyota-lc-2024',

          price: 100000,

        } as never,

        company: { id: 'c1', name: 'Gulf Motors' },

        offer: {} as never,

        financePartner: { code: 'al_jazeera', name: 'Al Jazeera Finance' } as never,

      } as never,

      'Al Jazeera Finance',

    );



    expect(payload.First_Name).toBe('Ali');

    expect(payload.Last_Name).toBe('Hassan');

    expect(payload.Email).toBe('customer@example.com');

    expect(payload.Mobile).toBe('+97455551234');

    expect(payload.Mobile_Reference).toBe('+974 5555 1234');

    expect(payload.Finance_Amount).toBe(90000);

    expect(payload.Re_payment_Period).toBe(36);

    expect(payload.Lead_Source).toBe('Blox Marketplace');

    expect(payload.Request_Submitted_To).toBe('Al Jazeera Finance');

    expect(payload.Basic_Salary_Qatari).toBe(15000);

    expect(payload.Monthly_Commitments).toBe(3200);

    expect(payload.Employment_Duration).toBe('Engineer');

    expect(payload.Work_Sector_Reference).toBe('Engineer');

    expect(payload.Subject_of_Message_from_Customer).toBe('Toyota Land Cruiser 2024 GXR');

    expect(String(payload.Reason_for_Request)).toContain('QID 28099887766');

    expect(String(payload.Sales_Agent_Comments)).toContain('QID: 28099887766');

    expect(String(payload.Sales_Agent_Comments)).toContain('Mobile: +974 5555 1234');

  });

});


