import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ZohoConfig {
  constructor(private readonly config: ConfigService) {}

  get enabled(): boolean {
    const token = this.refreshToken;
    if (!token || token.includes('<') || token.length < 20) return false;
    return Boolean(this.clientId && this.clientSecret && token);
  }

  get clientId(): string {
    return this.config.get<string>('ZOHO_CLIENT_ID') ?? '';
  }

  get clientSecret(): string {
    return this.config.get<string>('ZOHO_CLIENT_SECRET') ?? '';
  }

  get refreshToken(): string {
    return this.config.get<string>('ZOHO_REFRESH_TOKEN') ?? '';
  }

  get accountsUrl(): string {
    return this.config.get<string>('ZOHO_ACCOUNTS_URL') ?? 'https://accounts.zoho.com';
  }

  get apiDomain(): string {
    return this.config.get<string>('ZOHO_API_DOMAIN') ?? 'https://sandbox.zohoapis.com';
  }

  get requestSubmittedTo(): string {
    return this.config.get<string>('ZOHO_REQUEST_SUBMITTED_TO') ?? 'Al Jazeera Finance';
  }
}
