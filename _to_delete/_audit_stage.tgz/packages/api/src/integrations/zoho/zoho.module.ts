import { Module } from '@nestjs/common';
import { CommonModule } from '../../common/common.module';
import { ZohoAuthService } from './zoho-auth.service';
import { ZohoConfig } from './zoho-config';
import { ZohoCrmService } from './zoho-crm.service';

@Module({
  imports: [CommonModule],
  providers: [ZohoConfig, ZohoAuthService, ZohoCrmService],
  exports: [ZohoCrmService, ZohoConfig],
})
export class ZohoModule {}
