import type { Application, Company, FinancePartner, Offer, Product } from '@prisma/client';

export type ApplicationForZoho = Application & {
  product: Product;
  company: Pick<Company, 'id' | 'name'>;
  offer: Offer;
  financePartner: FinancePartner | null;
};

function splitName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return { firstName: 'Customer', lastName: 'Unknown' };
  if (parts.length === 1) return { firstName: parts[0], lastName: '.' };
  return { firstName: parts[0], lastName: parts.slice(1).join(' ') };
}

function normalizePhone(raw: unknown): { mobile: string; reference: string } {
  const display = String(raw ?? '').trim();
  if (!display) return { mobile: '', reference: '' };

  const digits = display.replace(/\D/g, '');
  if (!digits) return { mobile: '', reference: display };

  let mobile = digits;
  if (digits.length === 8) mobile = `974${digits}`;
  if (!mobile.startsWith('974') && digits.length <= 11) {
    mobile = `974${digits.replace(/^0+/, '')}`;
  }

  return {
    mobile: `+${mobile}`,
    reference: display.startsWith('+') ? display : `+${mobile}`,
  };
}

function compactPayload(payload: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(payload)) {
    if (value === undefined || value === null || value === '') continue;
    out[key] = value;
  }
  return out;
}

export function mapApplicationToZohoLead(
  app: ApplicationForZoho,
  requestSubmittedTo: string,
): Record<string, unknown> {
  const snap = (app.customerSnapshot ?? {}) as Record<string, unknown>;
  const pricing = (app.pricingSnapshot ?? {}) as Record<string, unknown>;
  const fullName = String(snap.full_name ?? app.customerEmail.split('@')[0] ?? 'Customer');
  const { firstName, lastName } = splitName(fullName);
  const { mobile, reference: mobileReference } = normalizePhone(snap.phone);

  const listPrice = Number(pricing.list_price ?? app.product.price ?? 0);
  const downPayment = Number(pricing.down_payment ?? 0);
  const downPaymentPct = Number(pricing.down_payment_pct ?? 0);
  const financeAmount = Math.max(listPrice - downPayment, 0);
  const tenor = Number(pricing.tenor ?? pricing.tenure ?? 0);
  const monthlyPayment = Number(pricing.monthly ?? 0);
  const monthlyIncome = Number(snap.income ?? 0);
  const qid = String(snap.qid ?? '').trim();
  const employment = String(snap.employment ?? '').trim();

  const leadSource =
    app.leadSource ??
    (app.agentUserId ? 'Blox Dealer Portal' : 'Blox Marketplace');

  const vehicleLabel = [
    app.product.make,
    app.product.model,
    app.product.modelYear ? String(app.product.modelYear) : null,
    app.product.trim ? app.product.trim : null,
  ]
    .filter(Boolean)
    .join(' ');

  const detailLines = [
    `Blox application: ${app.id}`,
    qid ? `QID: ${qid}` : null,
    mobileReference ? `Mobile: ${mobileReference}` : null,
    employment ? `Employment: ${employment}` : null,
    monthlyIncome > 0 ? `Monthly income: QAR ${monthlyIncome}` : null,
    `Vehicle: ${vehicleLabel}`,
    listPrice > 0 ? `List price: QAR ${listPrice}` : null,
    downPayment > 0 ? `Down payment: QAR ${downPayment}` : null,
    financeAmount > 0 ? `Finance amount: QAR ${financeAmount}` : null,
    tenor > 0 ? `Tenor: ${tenor} months` : null,
    monthlyPayment > 0 ? `Monthly payment: QAR ${monthlyPayment}` : null,
    app.company.name ? `Dealer: ${app.company.name}` : null,
    app.financePartner?.name ? `Finance partner: ${app.financePartner.name}` : null,
    app.product.slug ? `Listing: ${app.product.slug}` : null,
  ].filter(Boolean);

  const comments = detailLines.join('\n');
  const reasonForRequest = [
    qid ? `QID ${qid}` : null,
    employment ? employment : null,
    vehicleLabel ? `Vehicle ${vehicleLabel}` : null,
    financeAmount > 0 ? `Finance QAR ${financeAmount}` : null,
  ]
    .filter(Boolean)
    .join(' · ');

  const dealDigits = Number(app.id.replace(/\D/g, '').slice(-8));

  return compactPayload({
    First_Name: firstName,
    Last_Name: lastName,
    Email: app.customerEmail,
    Mobile: mobile,
    Phone: mobile,
    Mobile_Reference: mobileReference,
    Company: app.company.name || 'Walk-in',
    Lead_Source: leadSource,
    Finance_Amount: financeAmount > 0 ? financeAmount : undefined,
    Finance_Amount_Reference: financeAmount > 0 ? String(financeAmount) : undefined,
    Re_payment_Period: tenor > 0 ? tenor : undefined,
    Down_Payment_Reference:
      downPayment > 0
        ? `${downPayment}${downPaymentPct > 0 ? ` (${downPaymentPct}%)` : ''}`
        : undefined,
    Basic_Salary_Qatari: monthlyIncome > 0 ? monthlyIncome : undefined,
    Salary_Reference: monthlyIncome > 0 ? String(monthlyIncome) : undefined,
    Monthly_Commitments: monthlyPayment > 0 ? monthlyPayment : undefined,
    Employment_Duration: employment || undefined,
    Work_Sector_Reference: employment || undefined,
    Request_Submitted_To: requestSubmittedTo,
    Subject_of_Message_from_Customer: vehicleLabel || undefined,
    Sales_Agent_Comments: comments,
    Reason_for_Request: reasonForRequest || comments,
    Deal_Number: Number.isFinite(dealDigits) && dealDigits > 0 ? dealDigits : undefined,
  });
}
