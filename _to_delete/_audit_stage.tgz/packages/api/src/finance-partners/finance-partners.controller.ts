import { Controller, Get } from '@nestjs/common';
import { Public } from '../auth/guards';
import { PrismaService } from '../prisma/prisma.service';

@Controller('finance-partners')
export class FinancePartnersController {
  constructor(private readonly prisma: PrismaService) {}

  @Public()
  @Get()
  list() {
    return this.prisma.financePartner.findMany({
      where: { active: true },
      orderBy: { name: 'asc' },
      include: {
        offers: {
          where: { status: 'active' },
          orderBy: { name: 'asc' },
        },
      },
    });
  }
}
