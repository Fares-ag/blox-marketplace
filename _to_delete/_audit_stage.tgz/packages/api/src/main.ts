import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { toNodeHandler } from 'better-auth/node';
import rateLimit from 'express-rate-limit';
import type { Request, Response } from 'express';
import { AppModule } from './app.module';
import { createAuth } from './auth/auth';
import { resolveApiPort, resolveAuthSecret } from './auth/auth-config';
import { PrismaService } from './prisma/prisma.service';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bodyParser: false });
  const config = app.get(ConfigService);
  const prisma = app.get(PrismaService);

  resolveAuthSecret(config);

  const origins = (config.get<string>('CORS_ORIGINS') ?? 'http://localhost:5173')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);

  app.enableCors({
    origin: origins,
    credentials: true,
  });

  const expressApp = app.getHttpAdapter().getInstance();

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 60,
    standardHeaders: true,
    legacyHeaders: false,
    message: { message: 'rate_limit_exceeded' },
  });
  const applyLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { message: 'rate_limit_exceeded' },
  });

  expressApp.use('/api/auth', authLimiter);
  expressApp.use('/api/applications', applyLimiter);

  const auth = createAuth(prisma, config);
  const handler = toNodeHandler(auth);

  // Express 5: named wildcard required (bare `*` throws PathError)
  expressApp.all('/api/auth/*path', (req: Request, res: Response) => handler(req, res));

  // Re-enable JSON body parser for Nest routes (auth handler reads its own body)
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const express = require('express');
  expressApp.use(express.json({ limit: '10mb' }));
  expressApp.use(express.urlencoded({ extended: true }));

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  app.setGlobalPrefix('api', { exclude: [] });

  // Expose auth instance for session lookups in guards
  app.get(AppModule);
  (global as { __dmAuth?: typeof auth }).__dmAuth = auth;

  const port = resolveApiPort(config);
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`DriveMarket API http://localhost:${port}`);
  // eslint-disable-next-line no-console
  console.log(`Better Auth   http://localhost:${port}/api/auth`);
}

void bootstrap();
