import {

  BadRequestException,

  ForbiddenException,

  Injectable,

  NotFoundException,

} from '@nestjs/common';

import {

  ApplicationStatus,

  ListingStatus,

  Offer,

  Prisma,

  Product,

  User,

  UserRole,

} from '@prisma/client';

import { PrismaService } from '../prisma/prisma.service';

import { ActivityService } from '../common/activity.service';

import { StorageService } from '../storage/storage.service';

import { normalizeEmail, resolveQuoteGate } from '../quotes/quote-pricing';

import {

  assertOfferMatchesProduct,

  buildApplicationPricingSnapshot,

} from './application-pricing';

import { hasAllRequiredDocuments } from './application-documents';
import { ZohoCrmService } from '../integrations/zoho/zoho-crm.service';



const BLOCKING: ApplicationStatus[] = [

  'draft',

  'under_review',

  'resubmission_required',

  'contract_signing_required',

  'contracts_submitted',

  'contract_under_review',

  'down_payment_required',

  'down_payment_submitted',

  'pending_finance_activation',

  'active',

];



function asJson(value: Record<string, unknown>): Prisma.InputJsonValue {

  return value as Prisma.InputJsonValue;

}



@Injectable()

export class ApplicationsService {

  constructor(

    private readonly prisma: PrismaService,

    private readonly activity: ActivityService,

    private readonly storage: StorageService,

    private readonly zoho: ZohoCrmService,

  ) {}



  async hasBlocking(userId: string) {

    const found = await this.prisma.application.findFirst({

      where: { customerUserId: userId, status: { in: BLOCKING } },

      select: { id: true },

    });

    return { blocking: !!found, applicationId: found?.id ?? null };

  }



  async create(

    user: User,

    dto: {

      productId: string;

      offerId: string;

      customerSnapshot: Record<string, unknown>;

      pricingSnapshot: Record<string, unknown>;

      installmentPlan?: Record<string, unknown>;

      quoteToken?: string;

      financePartnerId?: string;

    },

  ) {

    if (user.role !== UserRole.customer) throw new ForbiddenException('forbidden_role');



    const product = await this.prisma.product.findUnique({ where: { id: dto.productId } });

    if (

      !product ||

      product.listingStatus !== ListingStatus.published ||

      !product.financeEligible

    ) {

      throw new BadRequestException('listing_not_available');

    }



    const offer = await this.resolveOfferForApply(product, {

      financePartnerId: dto.financePartnerId,

      requestedOfferId: dto.offerId,

    });

    try {

      assertOfferMatchesProduct(dto.offerId, offer.id);

    } catch {

      throw new BadRequestException('offer_mismatch');

    }



    const snap = dto.customerSnapshot;

    if (!snap.full_name || !snap.phone || !snap.qid) {

      throw new BadRequestException('validation_failed');

    }



    let agentUserId: string | undefined;

    let quoteId: string | undefined;

    let listPrice = Number(product.price);

    let pricingOffer: Pick<Offer, 'annualRentRate' | 'minDownPaymentPct' | 'tenureOptions'> =

      offer;



    if (dto.quoteToken) {

      const quote = await this.prisma.dealerQuote.findUnique({

        where: { token: dto.quoteToken },

        include: { offer: true },

      });

      if (!quote) throw new BadRequestException('quote_not_found');

      const gate = resolveQuoteGate(quote, user);

      if (gate !== 'active') throw new BadRequestException(`quote_${gate}`);

      if (quote.productId !== product.id) throw new BadRequestException('quote_product_mismatch');

      if (quote.offerId !== offer.id) throw new BadRequestException('offer_mismatch');



      listPrice = Number(quote.negotiatedPrice);

      pricingOffer = quote.offer;

      agentUserId = quote.createdByUserId;

      quoteId = quote.id;

    }



    const clientListPrice = dto.pricingSnapshot.list_price;

    if (clientListPrice !== undefined && Number(clientListPrice) !== listPrice) {

      throw new BadRequestException('price_mismatch');

    }



    let pricingSnapshot: Record<string, unknown>;

    try {

      pricingSnapshot = buildApplicationPricingSnapshot({

        listPrice,

        offer: pricingOffer,

        pricingSnapshot: dto.pricingSnapshot,

      });

    } catch (e) {

      if (e instanceof Error && e.message === 'invalid_tenure') {

        throw new BadRequestException('invalid_tenure');

      }

      throw e;

    }



    const app = await this.prisma.$transaction(async (tx) => {

      const blocking = await tx.application.findFirst({

        where: { customerUserId: user.id, status: { in: BLOCKING } },

        select: { id: true },

      });

      if (blocking) throw new BadRequestException('blocking_application_exists');



      const reserved = await tx.product.updateMany({

        where: {

          id: product.id,

          listingStatus: ListingStatus.published,

          financeEligible: true,

        },

        data: { listingStatus: ListingStatus.reserved },

      });

      if (reserved.count !== 1) throw new BadRequestException('listing_not_available');



      const created = await tx.application.create({

        data: {

          customerUserId: user.id,

          customerEmail: user.email,

          customerSnapshot: asJson(snap),

          productId: product.id,

          companyId: product.companyId,

          offerId: offer.id,

          financePartnerId: offer.financePartnerId ?? dto.financePartnerId ?? null,

          leadSource: 'Blox Marketplace',

          pricingSnapshot: asJson(pricingSnapshot),

          installmentPlan: dto.installmentPlan ? asJson(dto.installmentPlan) : undefined,

          status: ApplicationStatus.draft,

          agentUserId,

        },

      });



      if (quoteId) {

        const consumed = await tx.dealerQuote.updateMany({

          where: {

            id: quoteId,

            usedAt: null,

            revokedAt: null,

            expiresAt: { gt: new Date() },

          },

          data: {

            usedAt: new Date(),

            usedByApplicationId: created.id,

          },

        });

        if (consumed.count !== 1) throw new BadRequestException('quote_unavailable');

      }



      await tx.user.update({

        where: { id: user.id },

        data: {

          name: user.name || String(snap.full_name),

          phone: user.phone || String(snap.phone),

          qid: user.qid || String(snap.qid),

        },

      });



      return created;

    });



    await this.activity.log({

      actorUserId: user.id,

      entityType: 'application',

      entityId: app.id,

      action: 'application_created',

      toValue: 'draft',

    });



    return app;

  }



  private async notifyApplicationSubmitted(appId: string, companyId: string) {

    const notifyTargets = await this.prisma.user.findMany({

      where: {

        isActive: true,

        OR: [

          { role: UserRole.credit_officer, creditScope: 'all' },

          { role: UserRole.dealer_agent, companyId },

          { role: { in: [UserRole.admin, UserRole.super_admin] } },

        ],

      },

    });

    for (const t of notifyTargets) {

      await this.activity.notify(

        t.id,

        t.role === UserRole.dealer_agent ? 'New lead on your stock' : 'New financing application',

        'A customer submitted an application for credit review.',

        `/applications/${appId}`,

      );

    }

  }



  private async assertRequiredDocuments(appId: string) {

    const docs = await this.prisma.applicationDocument.findMany({

      where: { applicationId: appId },

      select: { category: true },

    });

    if (!hasAllRequiredDocuments(docs)) {

      throw new BadRequestException('documents_incomplete');

    }

  }



  async submit(user: User, id: string) {

    const app = await this.prisma.application.findUnique({ where: { id } });

    if (!app || app.customerUserId !== user.id) throw new ForbiddenException('forbidden_role');

    if (app.status !== 'draft') {

      throw new BadRequestException('invalid_status_transition');

    }

    await this.assertRequiredDocuments(id);

    const updated = await this.prisma.application.update({

      where: { id },

      data: { status: 'under_review', submittedAt: new Date() },

    });

    await this.activity.log({

      actorUserId: user.id,

      entityType: 'application',

      entityId: id,

      action: 'status_transition',

      fromValue: 'draft',

      toValue: 'under_review',

    });

    await this.notifyApplicationSubmitted(id, app.companyId);

    void this.triggerZohoSyncIfNeeded(id, user.id);

    return updated;

  }



  async syncToZoho(user: User, id: string) {

    const roleOk: UserRole[] = [UserRole.credit_officer, UserRole.admin, UserRole.super_admin];

    if (!roleOk.includes(user.role)) throw new ForbiddenException('forbidden_role');

    const app = await this.prisma.application.findUnique({

      where: { id },

      include: { financePartner: true },

    });

    if (!app) throw new NotFoundException();

    if (app.financePartner?.crmAdapter !== 'zoho') {

      throw new BadRequestException('partner_not_zoho');

    }

    return this.zoho.syncApplicationToZoho(id, user.id);

  }



  async createWalkIn(

    dealer: User,

    dto: {

      productId: string;

      offerId: string;

      financePartnerId: string;

      customerEmail: string;

      customerSnapshot: Record<string, unknown>;

      pricingSnapshot: Record<string, unknown>;

    },

  ) {

    if (dealer.role !== UserRole.dealer_agent || !dealer.companyId) {

      throw new ForbiddenException('forbidden_role');

    }



    const product = await this.prisma.product.findUnique({ where: { id: dto.productId } });

    if (

      !product ||

      product.companyId !== dealer.companyId ||

      product.listingStatus !== ListingStatus.published ||

      !product.financeEligible

    ) {

      throw new BadRequestException('listing_not_available');

    }



    const offer = await this.resolveOfferForApply(product, {

      financePartnerId: dto.financePartnerId,

      requestedOfferId: dto.offerId,

    });



    const snap = dto.customerSnapshot;

    if (!snap.full_name || !snap.phone || !snap.qid) {

      throw new BadRequestException('validation_failed');

    }



    const email = normalizeEmail(dto.customerEmail);

    if (!email) throw new BadRequestException('validation_failed');



    let pricingSnapshot: Record<string, unknown>;

    try {

      pricingSnapshot = buildApplicationPricingSnapshot({

        listPrice: Number(product.price),

        offer,

        pricingSnapshot: dto.pricingSnapshot,

      });

    } catch (e) {

      if (e instanceof Error && e.message === 'invalid_tenure') {

        throw new BadRequestException('invalid_tenure');

      }

      throw e;

    }



    const app = await this.prisma.$transaction(async (tx) => {

      let customer = await tx.user.findUnique({ where: { email } });

      if (!customer) {

        customer = await tx.user.create({

          data: {

            email,

            name: String(snap.full_name),

            role: UserRole.customer,

            phone: String(snap.phone),

            qid: String(snap.qid),

            emailVerified: false,

          },

        });

      }



      const blocking = await tx.application.findFirst({

        where: { customerUserId: customer.id, status: { in: BLOCKING } },

        select: { id: true },

      });

      if (blocking) throw new BadRequestException('blocking_application_exists');



      const reserved = await tx.product.updateMany({

        where: {

          id: product.id,

          listingStatus: ListingStatus.published,

          financeEligible: true,

        },

        data: { listingStatus: ListingStatus.reserved },

      });

      if (reserved.count !== 1) throw new BadRequestException('listing_not_available');



      return tx.application.create({

        data: {

          customerUserId: customer.id,

          customerEmail: email,

          customerSnapshot: asJson(snap),

          productId: product.id,

          companyId: product.companyId,

          offerId: offer.id,

          financePartnerId: offer.financePartnerId ?? dto.financePartnerId,

          leadSource: 'Blox Dealer Portal',

          pricingSnapshot: asJson(pricingSnapshot),

          status: ApplicationStatus.under_review,

          submittedAt: new Date(),

          agentUserId: dealer.id,

        },

      });

    });



    await this.activity.log({

      actorUserId: dealer.id,

      entityType: 'application',

      entityId: app.id,

      action: 'dealer_walk_in_created',

      toValue: 'under_review',

      metadata: { financePartnerId: dto.financePartnerId },

    });



    await this.notifyApplicationSubmitted(app.id, app.companyId);

    void this.triggerZohoSyncIfNeeded(app.id, dealer.id);

    return app;

  }



  private async triggerZohoSyncIfNeeded(applicationId: string, actorUserId?: string) {

    const app = await this.prisma.application.findUnique({

      where: { id: applicationId },

      include: { financePartner: true },

    });

    if (!app?.financePartner || app.financePartner.crmAdapter !== 'zoho') return;

    await this.zoho.syncApplicationToZoho(applicationId, actorUserId);

  }



  private async resolveOfferForApply(

    product: Pick<Product, 'defaultOfferId'>,

    opts: { financePartnerId?: string; requestedOfferId?: string },

  ): Promise<Offer> {

    if (opts.financePartnerId) {

      const partnerOffer = await this.prisma.offer.findFirst({

        where: {

          status: 'active',

          financePartnerId: opts.financePartnerId,

          ...(opts.requestedOfferId ? { id: opts.requestedOfferId } : {}),

        },

      });

      if (!partnerOffer) throw new BadRequestException('finance_partner_offer_not_found');

      return partnerOffer;

    }

    return this.resolveOfferForProduct(product);

  }



  private async resolveOfferForProduct(product: Pick<Product, 'defaultOfferId'>): Promise<Offer> {

    if (product.defaultOfferId) {

      const productOffer = await this.prisma.offer.findFirst({

        where: { id: product.defaultOfferId, status: 'active' },

      });

      if (productOffer) return productOffer;

    }



    const platformDefault = await this.prisma.offer.findFirst({

      where: { isDefault: true, status: 'active' },

    });

    if (!platformDefault) throw new BadRequestException('validation_failed');

    return platformDefault;

  }



  async listMine(user: User) {

    return this.prisma.application.findMany({

      where: { customerUserId: user.id },

      include: {

        product: { select: { make: true, model: true, modelYear: true, slug: true, price: true } },

      },

      orderBy: { createdAt: 'desc' },

    });

  }



  async getOne(user: User, id: string) {

    const app = await this.prisma.application.findUnique({

      where: { id },

      include: {

        product: true,

        documents: true,

        paymentSchedules: { orderBy: { sequence: 'asc' } },

        company: { select: { id: true, name: true } },

        offer: true,

        financePartner: true,

      },

    });

    if (!app) throw new NotFoundException();

    this.assertCanView(user, app);

    const safeProduct = { ...app.product, vin: undefined, chassisNumber: undefined };

    if (user.role === UserRole.customer || user.role === UserRole.dealer_agent) {

      // dealer can see lead; still hide nothing critical for MVP dealer

    }

    return { ...app, product: safeProduct };

  }



  async opsQueue(user: User) {

    const allowed: UserRole[] = [

      UserRole.credit_officer,

      UserRole.admin,

      UserRole.super_admin,

      UserRole.finance_officer,

    ];

    if (!allowed.includes(user.role)) {

      throw new ForbiddenException('forbidden_role');

    }

    return this.prisma.application.findMany({

      where: {

        status: {

          in: [

            'under_review',

            'resubmission_required',

            'contract_signing_required',

            'contracts_submitted',

            'contract_under_review',

            'pending_finance_activation',

          ],

        },

      },

      include: {

        product: { select: { make: true, model: true, modelYear: true, slug: true } },

        company: { select: { name: true } },

        customer: { select: { name: true, email: true } },

      },

      orderBy: { createdAt: 'asc' },

    });

  }



  async dealerLeads(user: User) {

    if (user.role !== UserRole.dealer_agent || !user.companyId) {

      throw new ForbiddenException('forbidden_role');

    }

    return this.prisma.application.findMany({

      where: { companyId: user.companyId },

      include: {

        product: { select: { make: true, model: true, modelYear: true, slug: true } },

        customer: { select: { name: true, email: true, phone: true } },

      },

      orderBy: { createdAt: 'desc' },

    });

  }



  async transition(

    user: User,

    id: string,

    toStatus: ApplicationStatus,

    reason?: string,

  ) {

    const roleOk: UserRole[] = [UserRole.credit_officer, UserRole.admin, UserRole.super_admin];

    if (!roleOk.includes(user.role)) {

      throw new ForbiddenException('forbidden_role');

    }

    const app = await this.prisma.application.findUnique({ where: { id } });

    if (!app) throw new NotFoundException();



    let transitionOk = false;

    if (app.status === 'under_review' && (toStatus === 'rejected' || toStatus === 'resubmission_required')) {

      transitionOk = true;

    }

    if (app.status === 'resubmission_required' && toStatus === 'rejected') transitionOk = true;

    if (!transitionOk) throw new BadRequestException('invalid_status_transition');

    if ((toStatus === 'rejected' || toStatus === 'resubmission_required') && !reason?.trim()) {

      throw new BadRequestException('validation_failed');

    }



    const updated = await this.prisma.$transaction(async (tx) => {

      const next = await tx.application.update({

        where: { id },

        data: {

          status: toStatus,

          statusReason: reason,

          rejectionReason: toStatus === 'rejected' ? reason : app.rejectionReason,

          resubmissionComment:

            toStatus === 'resubmission_required' ? reason : app.resubmissionComment,

        },

      });



      if (toStatus === 'rejected' || toStatus === 'submission_cancelled') {

        const stillBlocking = await tx.application.findFirst({

          where: {

            productId: app.productId,

            id: { not: id },

            status: { in: BLOCKING },

          },

        });

        if (!stillBlocking) {

          await tx.product.update({

            where: { id: app.productId },

            data: { listingStatus: ListingStatus.published },

          });

        }

      }

      return next;

    });



    await this.activity.log({

      actorUserId: user.id,

      entityType: 'application',

      entityId: id,

      action: 'status_transition',

      fromValue: app.status,

      toValue: toStatus,

      metadata: { reason },

    });

    await this.activity.notify(

      app.customerUserId,

      toStatus === 'rejected' ? 'Application rejected' : 'Documents required',

      reason,

      `/app/applications/${id}`,

    );

    return updated;

  }



  async resubmit(user: User, id: string) {

    const app = await this.prisma.application.findUnique({ where: { id } });

    if (!app || app.customerUserId !== user.id) throw new ForbiddenException('forbidden_role');

    if (app.status !== 'resubmission_required') {

      throw new BadRequestException('invalid_status_transition');

    }

    await this.assertRequiredDocuments(id);

    const updated = await this.prisma.application.update({

      where: { id },

      data: { status: 'under_review' },

    });

    await this.activity.log({

      actorUserId: user.id,

      entityType: 'application',

      entityId: id,

      action: 'status_transition',

      fromValue: 'resubmission_required',

      toValue: 'under_review',

    });

    return updated;

  }



  async cancel(user: User, id: string, reason?: string) {

    const app = await this.prisma.application.findUnique({ where: { id } });

    if (!app || app.customerUserId !== user.id) throw new ForbiddenException('forbidden_role');

    if (!['draft', 'under_review', 'resubmission_required'].includes(app.status)) {

      throw new BadRequestException('invalid_status_transition');

    }

    const updated = await this.prisma.$transaction(async (tx) => {

      const next = await tx.application.update({

        where: { id },

        data: { status: 'submission_cancelled', statusReason: reason },

      });

      const stillBlocking = await tx.application.findFirst({

        where: {

          productId: app.productId,

          id: { not: id },

          status: { in: BLOCKING },

        },

      });

      if (!stillBlocking) {

        await tx.product.update({

          where: { id: app.productId },

          data: { listingStatus: ListingStatus.published },

        });

      }

      return next;

    });

    await this.activity.log({

      actorUserId: user.id,

      entityType: 'application',

      entityId: id,

      action: 'status_transition',

      toValue: 'submission_cancelled',

    });

    return updated;

  }



  async uploadDoc(

    user: User,

    id: string,

    category: 'qid' | 'salary' | 'bank' | 'other',

    file: Express.Multer.File,

  ) {

    const app = await this.prisma.application.findUnique({ where: { id } });

    if (!app || app.customerUserId !== user.id) throw new ForbiddenException('forbidden_role');

    if (!['resubmission_required', 'draft'].includes(app.status)) {

      throw new BadRequestException('validation_failed');

    }

    this.storage.assertKycFile(file);

    const key = await this.storage.uploadKyc(file, id, category);

    return this.prisma.applicationDocument.create({

      data: {

        applicationId: id,

        category,

        storagePath: key,

        mimeType: file.mimetype,

        uploadedById: user.id,

      },

    }).then(async (doc) => {

      void this.triggerZohoSyncIfNeeded(id, user.id);

      return doc;

    });

  }

  async downloadDocument(user: User, applicationId: string, documentId: string) {
    const doc = await this.prisma.applicationDocument.findFirst({
      where: { id: documentId, applicationId },
    });
    if (!doc) throw new NotFoundException();

    const app = await this.prisma.application.findUnique({ where: { id: applicationId } });
    if (!app) throw new NotFoundException();
    this.assertCanView(user, app);

    const { buffer, contentType } = await this.storage.readKyc(doc.storagePath);
    const filename = doc.storagePath.split('/').pop() ?? `${doc.category}-document`;
    return {
      buffer,
      contentType: doc.mimeType ?? contentType,
      filename,
    };
  }

  private assertCanView(

    user: User,

    app: { customerUserId: string; companyId: string },

  ) {

    if (user.role === UserRole.customer && app.customerUserId === user.id) return;

    if (user.role === UserRole.dealer_agent && user.companyId === app.companyId) return;

    const ops: UserRole[] = [

      UserRole.credit_officer,

      UserRole.finance_officer,

      UserRole.admin,

      UserRole.super_admin,

    ];

    if (ops.includes(user.role)) {

      return;

    }

    throw new ForbiddenException('forbidden_role');

  }

}


