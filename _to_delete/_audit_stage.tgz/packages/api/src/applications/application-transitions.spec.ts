import { describe, expect, it } from 'vitest';
import { UserRole } from '@prisma/client';
import {
  assertOpsTransitionAllowed,
  findTransitionRule,
  opsTransitionRequiresReason,
} from './application-transitions';

describe('application-transitions', () => {
  it('allows credit to reject from under_review', () => {
    expect(() =>
      assertOpsTransitionAllowed('under_review', 'rejected', UserRole.credit_officer),
    ).not.toThrow();
  });

  it('requires reason for reject', () => {
    expect(opsTransitionRequiresReason('under_review', 'rejected')).toBe(true);
  });

  it('allows contract review progression', () => {
    expect(findTransitionRule('contracts_submitted', 'contract_under_review')).toBeDefined();
    expect(findTransitionRule('contract_under_review', 'pending_finance_activation')).toBeDefined();
  });

  it('forbids finance officer on ops transitions', () => {
    expect(() =>
      assertOpsTransitionAllowed('under_review', 'rejected', UserRole.finance_officer),
    ).toThrow('invalid_status_transition');
  });

  it('forbids customer on ops transitions', () => {
    expect(() =>
      assertOpsTransitionAllowed('contracts_submitted', 'contract_under_review', UserRole.customer),
    ).toThrow('invalid_status_transition');
  });
});
