import type { ConfigService } from '@nestjs/config';

/** Hard-coded fallback in auth.ts — must never be used in production. */
export const INSECURE_AUTH_SECRET = 'dev-secret-change-me';

export function resolveAuthSecret(config: ConfigService): string {
  const secret = config.get<string>('BETTER_AUTH_SECRET')?.trim();

  if (!secret) {
    throw new Error(
      'BETTER_AUTH_SECRET is required. Copy packages/api/.env.example to packages/api/.env and set a strong secret.',
    );
  }

  if (secret === INSECURE_AUTH_SECRET) {
    throw new Error(
      'BETTER_AUTH_SECRET must not use the insecure dev default. Set a unique value in packages/api/.env',
    );
  }

  if (secret.length < 32) {
    throw new Error('BETTER_AUTH_SECRET must be at least 32 characters.');
  }

  return secret;
}

export function resolveAuthBaseUrl(config: ConfigService): string {
  return config.get<string>('BETTER_AUTH_URL') ?? 'http://localhost:3010';
}

export function resolveApiPort(config: ConfigService): number {
  // Railway injects PORT; prefer it over API_PORT for platform deploys.
  const port = process.env.PORT ?? config.get<string>('API_PORT') ?? 3010;
  return Number(port);
}

/** When set (e.g. `.blox.market`), enables cross-subdomain session cookies in production. */
export function resolveCookieDomain(config: ConfigService): string | undefined {
  const domain = config.get<string>('COOKIE_DOMAIN')?.trim();
  return domain || undefined;
}
