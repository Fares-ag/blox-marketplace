/**
 * Direct Zoho sync test (loads .env, no API restart needed).
 *   node packages/api/scripts/smoke-zoho-direct.mjs [applicationId]
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PrismaClient } from '@prisma/client';

const __dirname = dirname(fileURLToPath(import.meta.url));
const envPath = resolve(__dirname, '../.env');
for (const line of readFileSync(envPath, 'utf8').split('\n')) {
  const t = line.trim();
  if (!t || t.startsWith('#')) continue;
  const i = t.indexOf('=');
  if (i === -1) continue;
  process.env[t.slice(0, i).trim()] = t.slice(i + 1).trim();
}

const prisma = new PrismaClient();
const appIdArg = process.argv[2];

async function getAccessToken() {
  const url = new URL('/oauth/v2/token', process.env.ZOHO_ACCOUNTS_URL ?? 'https://accounts.zoho.com');
  url.searchParams.set('grant_type', 'refresh_token');
  url.searchParams.set('client_id', process.env.ZOHO_CLIENT_ID ?? '');
  url.searchParams.set('client_secret', process.env.ZOHO_CLIENT_SECRET ?? '');
  url.searchParams.set('refresh_token', process.env.ZOHO_REFRESH_TOKEN ?? '');
  const res = await fetch(url.toString(), { method: 'POST' });
  const text = await res.text();
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    throw new Error(`Token refresh non-JSON (${res.status}): ${text.slice(0, 300)}`);
  }
  if (!res.ok || !body.access_token) {
    throw new Error(`Token refresh failed: ${JSON.stringify(body)}`);
  }
  console.log('✓ Access token obtained, api_domain:', body.api_domain ?? process.env.ZOHO_API_DOMAIN);
  return body.access_token;
}

function splitName(fullName) {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return { firstName: 'Customer', lastName: 'Unknown' };
  if (parts.length === 1) return { firstName: parts[0], lastName: '.' };
  return { firstName: parts[0], lastName: parts.slice(1).join(' ') };
}

function mapLead(app) {
  const snap = app.customerSnapshot ?? {};
  const pricing = app.pricingSnapshot ?? {};
  const fullName = String(snap.full_name ?? app.customerEmail.split('@')[0]);
  const { firstName, lastName } = splitName(fullName);
  const listPrice = Number(pricing.list_price ?? app.product.price ?? 0);
  const downPayment = Number(pricing.down_payment ?? 0);
  return {
    First_Name: firstName,
    Last_Name: lastName,
    Email: app.customerEmail,
    Mobile: String(snap.phone ?? ''),
    Company: app.company.name || 'Walk-in',
    Lead_Source: app.leadSource ?? 'Blox Dealer Portal',
    Finance_Amount: Math.max(listPrice - downPayment, 0),
    Re_payment_Period: Number(pricing.tenor ?? 0) || undefined,
    Basic_Salary_Qatari: Number(snap.income ?? 0) || undefined,
    Request_Submitted_To: process.env.ZOHO_REQUEST_SUBMITTED_TO ?? 'Al Jazeera Finance',
    Sales_Agent_Comments: `Blox application ${app.id} · ${app.product.make} ${app.product.model}`,
  };
}

async function main() {
  console.log('Direct Zoho sync test\n');

  const token = await getAccessToken();
  const apiDomain = process.env.ZOHO_API_DOMAIN ?? 'https://sandbox.zohoapis.com';

  let app;
  if (appIdArg) {
    app = await prisma.application.findUnique({
      where: { id: appIdArg },
      include: { product: true, company: true, financePartner: true },
    });
  } else {
    app = await prisma.application.findFirst({
      where: { financePartner: { code: 'al_jazeera' } },
      orderBy: { createdAt: 'desc' },
      include: { product: true, company: true, financePartner: true },
    });
  }

  if (!app) throw new Error('No Al Jazeera application found');
  console.log('Application:', app.id, '|', app.customerEmail, '|', app.product.make, app.product.model);

  const payload = mapLead(app);
  console.log('Lead payload:', JSON.stringify(payload, null, 2));

  const res = await fetch(`${apiDomain}/crm/v8/Leads`, {
    method: 'POST',
    headers: {
      Authorization: `Zoho-oauthtoken ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ data: [payload] }),
  });

  const text = await res.text();
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    throw new Error(`Create lead non-JSON (${res.status}): ${text.slice(0, 500)}`);
  }

  console.log('\nZoho response:', JSON.stringify(body, null, 2));

  const row = body.data?.[0];
  if (row?.code !== 'SUCCESS' || !row.details?.id) {
    throw new Error(row?.message ?? 'Lead create failed');
  }

  await prisma.application.update({
    where: { id: app.id },
    data: {
      zohoLeadId: row.details.id,
      zohoSyncedAt: new Date(),
      zohoSyncError: null,
    },
  });

  console.log('\n✓ Lead created in Zoho:', row.details.id);
  console.log('  View: https://crmsandbox.zoho.com/crm/bloxmu/tab/Leads');
}

main()
  .catch((e) => {
    console.error('\nFAILED:', e.message);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
