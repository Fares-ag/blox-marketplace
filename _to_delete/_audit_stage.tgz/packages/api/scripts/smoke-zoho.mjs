/**
 * Zoho CRM smoke test — dealer walk-in with Al Jazeera Finance.
 * Requires API up + valid ZOHO_* env in packages/api/.env
 *
 *   node packages/api/scripts/smoke-zoho.mjs
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const envPath = resolve(__dirname, '../.env');
for (const line of readFileSync(envPath, 'utf8').split('\n')) {
  const t = line.trim();
  if (!t || t.startsWith('#')) continue;
  const i = t.indexOf('=');
  if (i === -1) continue;
  process.env[t.slice(0, i).trim()] = t.slice(i + 1).trim();
}

const BASE = process.env.API_URL ?? 'http://localhost:3010';
const ORIGIN = process.env.ORIGIN ?? 'http://localhost:5174';
const PASSWORD = 'Password123!';

class Session {
  cookies = new Map();
  absorbCookies(res) {
    const raw = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const line of raw) {
      const [pair] = line.split(';');
      const eq = pair.indexOf('=');
      if (eq === -1) continue;
      this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }
  cookieHeader() {
    return [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }
  async request(path, init = {}) {
    const headers = new Headers(init.headers);
    headers.set('Origin', ORIGIN);
    const cookie = this.cookieHeader();
    if (cookie) headers.set('Cookie', cookie);
    const res = await fetch(`${BASE}${path}`, { ...init, headers });
    this.absorbCookies(res);
    return res;
  }
}

async function signIn(session, email) {
  const res = await session.request('/api/auth/sign-in/email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: PASSWORD }),
  });
  if (!res.ok) throw new Error(`sign-in failed (${email}): ${res.status} ${await res.text()}`);
}

async function json(session, path, init = {}) {
  const res = await session.request(path, init);
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!res.ok) {
    throw new Error(`${init.method ?? 'GET'} ${path} → ${res.status}: ${typeof data === 'string' ? data : JSON.stringify(data)}`);
  }
  return data;
}

function buildPricing(listPrice, rate = 11.5) {
  const downPaymentPct = 10;
  const tenor = 36;
  const downPayment = (listPrice * downPaymentPct) / 100;
  const principal = listPrice - downPayment;
  const r = rate / 100 / 12;
  const factor = Math.pow(1 + r, tenor);
  const monthly = Math.round((principal * r * factor) / (factor - 1));
  return {
    list_price: listPrice,
    down_payment: downPayment,
    down_payment_pct: downPaymentPct,
    tenor,
    rate,
    monthly,
  };
}

async function main() {
  console.log('Zoho smoke test →', BASE);

  const refresh = process.env.ZOHO_REFRESH_TOKEN ?? '';
  if (!refresh || refresh.includes('<') || refresh.length < 20) {
    console.warn('\n⚠ ZOHO_REFRESH_TOKEN missing or still a placeholder in packages/api/.env');
    console.warn('  Exchange your grant code first, then re-run this script.\n');
  }

  const partners = await fetch(`${BASE}/api/finance-partners`).then((r) => r.json());
  const alJazeera = partners.find((p) => p.code === 'al_jazeera');
  if (!alJazeera) throw new Error('Al Jazeera finance partner not found — run db:seed');
  const offer = alJazeera.offers?.[0];
  if (!offer) throw new Error('No active offer for Al Jazeera — run db:seed');

  console.log('✓ Finance partner:', alJazeera.name, `(crmAdapter: ${alJazeera.crmAdapter})`);

  const dealer = new Session();
  const credit = new Session();
  await signIn(dealer, 'dealer@drivemarket.local');

  const inventory = await json(dealer, '/api/dealer/inventory');
  const product = inventory.find((p) => p.listingStatus === 'published' && p.financeEligible !== false);
  if (!product) throw new Error('No published finance-eligible inventory — run db:seed or publish a listing');

  const demoEmail = `zoho-demo-${Date.now()}@drivemarket.local`;
  console.log('Creating walk-in application for', product.make, product.model);
  console.log('  customer:', demoEmail);

  const created = await json(dealer, '/api/dealer/applications', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      productId: product.id,
      offerId: offer.id,
      financePartnerId: alJazeera.id,
      customerEmail: demoEmail,
      customerSnapshot: {
        full_name: 'Zoho Demo Customer',
        phone: '+974 5555 4242',
        qid: '28099887766',
        employment: 'Engineer',
        income: 18000,
      },
      pricingSnapshot: buildPricing(Number(product.price), Number(offer.annualRentRate)),
    }),
  });

  console.log('✓ Application created:', created.id, 'status:', created.status);

  await signIn(credit, 'credit@drivemarket.local');
  let app = await json(credit, `/api/applications/${created.id}`);

  console.log('\n--- Zoho sync status (after walk-in) ---');
  console.log('  financePartner:', app.financePartner?.name ?? '—');
  console.log('  leadSource:', app.leadSource ?? '—');
  console.log('  zohoLeadId:', app.zohoLeadId ?? '(none)');
  console.log('  zohoSyncedAt:', app.zohoSyncedAt ?? '(none)');
  console.log('  zohoSyncError:', app.zohoSyncError ?? '(none)');

  if (!app.zohoLeadId && app.financePartner?.crmAdapter === 'zoho') {
    console.log('\nRetrying via ops sync-zoho…');
    const sync = await json(credit, `/api/ops/applications/${created.id}/sync-zoho`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
    console.log('  sync result:', JSON.stringify(sync));
    app = await json(credit, `/api/applications/${created.id}`);
    console.log('  zohoLeadId:', app.zohoLeadId ?? '(none)');
    console.log('  zohoSyncError:', app.zohoSyncError ?? '(none)');
  }

  if (app.zohoLeadId) {
    console.log('\n✓ Zoho smoke test PASSED — lead ID:', app.zohoLeadId);
    console.log('  Check sandbox CRM: https://crmsandbox.zoho.com/crm/bloxmu/tab/Leads');
    return;
  }

  if (app.zohoSyncError) {
    throw new Error(`Zoho sync failed: ${app.zohoSyncError}`);
  }

  throw new Error('No Zoho lead created and no error recorded — check ZOHO_* env and API logs');
}

main().catch((err) => {
  console.error('\nZoho smoke test FAILED:', err.message);
  process.exit(1);
});
