/**
 * Seed only Chery inventory (production-safe — no demo users/vehicles).
 *   node packages/api/scripts/seed-chery-only.mjs
 */
import { PrismaClient } from '@prisma/client';
import { seedCheryInventory } from '../prisma/seed-chery.ts';

const prisma = new PrismaClient();

async function main() {
  await prisma.offer.upsert({
    where: { id: 'seed-default-offer' },
    update: { status: 'active', isDefault: true },
    create: {
      id: 'seed-default-offer',
      name: 'Standard DriveMarket Finance',
      annualRentRate: 12.5,
      tenureOptions: [12, 24, 36, 48, 60],
      isDefault: true,
      status: 'active',
      minDownPaymentPct: 10,
    },
  });

  const result = await seedCheryInventory(prisma, 'seed-default-offer');
  console.log(`✓ Published Chery inventory: ${result.count} vehicles (company ${result.companyId})`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
