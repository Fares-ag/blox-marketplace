import { PrismaClient, UserRole } from '@prisma/client';
import { hashPassword } from 'better-auth/crypto';
import { seedCheryInventory } from './seed-chery';

const prisma = new PrismaClient();
const PASSWORD = 'Password123!';

async function upsertUser(opts: {
  email: string;
  name: string;
  role: UserRole;
  companyId?: string;
  creditScope?: 'all' | 'assigned';
  financeScope?: 'all' | 'assigned';
}) {
  const password = await hashPassword(PASSWORD);
  const existing = await prisma.user.findUnique({ where: { email: opts.email } });
  if (existing) {
    await prisma.user.update({
      where: { id: existing.id },
      data: {
        role: opts.role,
        companyId: opts.companyId ?? null,
        creditScope: opts.creditScope ?? 'assigned',
        financeScope: opts.financeScope ?? 'assigned',
        emailVerified: true,
        name: opts.name,
      },
    });
    await prisma.account.deleteMany({ where: { userId: existing.id, providerId: 'credential' } });
    await prisma.account.create({
      data: {
        userId: existing.id,
        accountId: existing.id,
        providerId: 'credential',
        password,
      },
    });
    return existing.id;
  }

  const user = await prisma.user.create({
    data: {
      email: opts.email,
      name: opts.name,
      emailVerified: true,
      role: opts.role,
      companyId: opts.companyId,
      creditScope: opts.creditScope ?? 'assigned',
      financeScope: opts.financeScope ?? 'assigned',
    },
  });
  await prisma.account.create({
    data: {
      userId: user.id,
      accountId: user.id,
      providerId: 'credential',
      password,
    },
  });
  return user.id;
}

async function main() {
  const company = await prisma.company.upsert({
    where: { code: 'GULF' },
    update: {
      name: 'Gulf Motors Demo',
      status: 'active',
      contactPhone: '+974 4444 1000',
    },
    create: {
      name: 'Gulf Motors Demo',
      code: 'GULF',
      status: 'active',
      contactEmail: 'dealer@drivemarket.local',
      contactPhone: '+974 4444 1000',
      canPay: false,
    },
  });

  await prisma.financePartner.upsert({
    where: { code: 'al_jazeera' },
    update: { name: 'Al Jazeera Finance', active: true, crmAdapter: 'zoho' },
    create: {
      id: 'seed-al-jazeera',
      code: 'al_jazeera',
      name: 'Al Jazeera Finance',
      active: true,
      crmAdapter: 'zoho',
    },
  });

  await prisma.financePartner.upsert({
    where: { code: 'blox_finance' },
    update: { name: 'Blox Finance', active: true, crmAdapter: 'none' },
    create: {
      id: 'seed-blox-finance',
      code: 'blox_finance',
      name: 'Blox Finance',
      active: true,
      crmAdapter: 'none',
    },
  });

  await prisma.offer.upsert({
    where: { id: 'seed-default-offer' },
    update: { financePartnerId: 'seed-blox-finance' },
    create: {
      id: 'seed-default-offer',
      name: 'Standard DriveMarket Finance',
      annualRentRate: 12.5,
      tenureOptions: [12, 24, 36, 48, 60],
      isDefault: true,
      status: 'active',
      minDownPaymentPct: 10,
      financePartnerId: 'seed-blox-finance',
    },
  });

  await prisma.offer.upsert({
    where: { id: 'seed-al-jazeera-offer' },
    update: {
      financePartnerId: 'seed-al-jazeera',
      annualRentRate: 11.5,
      name: 'Al Jazeera Finance Plan',
    },
    create: {
      id: 'seed-al-jazeera-offer',
      name: 'Al Jazeera Finance Plan',
      annualRentRate: 11.5,
      tenureOptions: [12, 24, 36, 48, 60],
      isDefault: false,
      status: 'active',
      minDownPaymentPct: 10,
      financePartnerId: 'seed-al-jazeera',
    },
  });

  await upsertUser({
    email: 'customer@drivemarket.local',
    name: 'Demo Customer',
    role: UserRole.customer,
  });
  await upsertUser({
    email: 'dealer@drivemarket.local',
    name: 'Demo Dealer',
    role: UserRole.dealer_agent,
    companyId: company.id,
  });
  await upsertUser({
    email: 'credit@drivemarket.local',
    name: 'Demo Credit',
    role: UserRole.credit_officer,
    creditScope: 'all',
  });
  await upsertUser({
    email: 'finance@drivemarket.local',
    name: 'Demo Finance',
    role: UserRole.finance_officer,
    financeScope: 'all',
  });
  await upsertUser({
    email: 'admin@drivemarket.local',
    name: 'Demo Admin',
    role: UserRole.admin,
    creditScope: 'all',
    financeScope: 'all',
  });
  await upsertUser({
    email: 'super@drivemarket.local',
    name: 'Demo Super',
    role: UserRole.super_admin,
    creditScope: 'all',
    financeScope: 'all',
  });

  const chery = await seedCheryInventory(prisma, 'seed-default-offer');

  await upsertUser({
    email: 'dealer.chery@blox.test',
    name: 'Elite Motors Agent',
    role: UserRole.dealer_agent,
    companyId: chery.companyId,
  });

  // eslint-disable-next-line no-console
  console.log('Seed complete. Password for all users:', PASSWORD);
  // eslint-disable-next-line no-console
  console.log(`Published Chery inventory: ${chery.count} (dealer Elite Motors, code CHERY)`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
