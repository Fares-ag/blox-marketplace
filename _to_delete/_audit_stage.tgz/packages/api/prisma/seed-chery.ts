import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  BodyType,
  Drivetrain,
  PrismaClient,
  Transmission,
  VehicleCondition,
} from '@prisma/client';

type CheryImportRow = {
  id: string;
  make: string;
  model: string;
  trim: string | null;
  year: number;
  color: string;
  price: number;
  gear: string;
  drive: string;
  body: string;
  condition: string;
  mileage: number;
  title: string;
};

function mapTransmission(gear: string): Transmission {
  return gear.toLowerCase() === 'manual' ? Transmission.manual : Transmission.automatic;
}

function mapDrivetrain(drive: string): Drivetrain {
  switch (drive.toUpperCase()) {
    case 'RWD':
      return Drivetrain.rwd;
    case 'AWD':
      return Drivetrain.awd;
    case '4WD':
      return Drivetrain.four_wd;
    default:
      return Drivetrain.fwd;
  }
}

function mapBodyType(body: string): BodyType {
  switch (body.toLowerCase()) {
    case 'sedan':
      return BodyType.sedan;
    case 'pick up':
    case 'pickup':
      return BodyType.pickup;
    case 'suv':
      return BodyType.suv;
    default:
      return BodyType.other;
  }
}

function cheryDescription(row: CheryImportRow): string {
  const trimPart = row.trim ? ` ${row.trim}` : '';
  return `${row.model}${trimPart} ${row.year} ${row.gear} ${row.body} ${row.drive}`.trim();
}

export async function seedCheryInventory(
  prisma: PrismaClient,
  defaultOfferId: string,
): Promise<{ companyId: string; count: number }> {
  const jsonPath = join(process.cwd(), 'scripts', 'chery-elite-motors-import.json');
  const raw = readFileSync(jsonPath, 'utf8').replace(/^\uFEFF/, '');
  const rows = JSON.parse(raw) as CheryImportRow[];

  const cheryCompany = await prisma.company.upsert({
    where: { code: 'CHERY' },
    update: {
      name: 'Elite Motors',
      status: 'active',
      canPay: true,
      branding: {
        brand: 'Chery',
        legal_name: 'Elite Motors',
        showroom_uri: 'elite_motors_2',
        source: 'qatarsale',
      },
    },
    create: {
      name: 'Elite Motors',
      code: 'CHERY',
      status: 'active',
      canPay: true,
      contactPhone: '+974 4000 2000',
      branding: {
        brand: 'Chery',
        legal_name: 'Elite Motors',
        showroom_uri: 'elite_motors_2',
        source: 'qatarsale',
      },
    },
  });

  for (const row of rows) {
    const slug = row.id;
    const product = await prisma.product.upsert({
      where: { slug },
      update: {
        companyId: cheryCompany.id,
        make: row.make,
        model: row.model,
        trim: row.trim,
        modelYear: row.year,
        condition: row.condition === 'new' ? VehicleCondition.new : VehicleCondition.used,
        transmission: mapTransmission(row.gear),
        drivetrain: mapDrivetrain(row.drive),
        bodyType: mapBodyType(row.body),
        color: row.color,
        mileage: row.mileage,
        description: cheryDescription(row),
        price: row.price,
        financeEligible: true,
        defaultOfferId,
        listingStatus: 'published',
        publishedAt: new Date(),
      },
      create: {
        companyId: cheryCompany.id,
        slug,
        make: row.make,
        model: row.model,
        trim: row.trim,
        modelYear: row.year,
        condition: row.condition === 'new' ? VehicleCondition.new : VehicleCondition.used,
        transmission: mapTransmission(row.gear),
        drivetrain: mapDrivetrain(row.drive),
        bodyType: mapBodyType(row.body),
        color: row.color,
        mileage: row.mileage,
        description: cheryDescription(row),
        price: row.price,
        financeEligible: true,
        defaultOfferId,
        listingStatus: 'published',
        publishedAt: new Date(),
      },
    });

    const imagePath = `/vehicles/${row.id}.webp`;
    await prisma.productImage.deleteMany({ where: { productId: product.id } });
    await prisma.productImage.create({
      data: {
        productId: product.id,
        storagePath: imagePath,
        sortOrder: 0,
        altText: `${row.make} ${row.model}${row.trim ? ` ${row.trim}` : ''}`,
      },
    });
  }

  return { companyId: cheryCompany.id, count: rows.length };
}
