import { StrictMode, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider, CssBaseline } from '@mui/material';
import {
  AuthGuard,
  LoginPage,
  BloxShell,
  bloxThemeWithBrand,
  useAuthStore,
  OpsPageHeader,
  OpsStatusPill,
  OpsDataTable,
  OpsStatCard,
  ScrollToTop,
  type BloxNavItem,
  type OpsPillVariant,
} from '@drivemarket/shared';

const queryClient = new QueryClient();
const nav: BloxNavItem[] = [
  { to: '/', label: 'Schedules', icon: 'finance' },
  { to: '/applications', label: 'Applications', icon: 'apps' },
];

const scheduleRows = [
  { id: 'SCH-1102', customer: 'Sara Al-Mannai', vehicle: 'Toyota Camry SE', due: '2026-08-15', amount: 'QAR 2,940', status: 'pending' as const },
  { id: 'SCH-1101', customer: 'Ahmed Al-Kuwari', vehicle: 'Hyundai Tucson Limited', due: '2026-08-01', amount: 'QAR 3,590', status: 'paid' as const },
  { id: 'SCH-1100', customer: 'Fatima Al-Thani', vehicle: 'Kia Sportage GT', due: '2026-07-28', amount: 'QAR 2,610', status: 'paid' as const },
  { id: 'SCH-1099', customer: 'Khalid Al-Emadi', vehicle: 'BMW 320i M Sport', due: '2026-07-20', amount: 'QAR 5,120', status: 'pending' as const },
];

const appRows = [
  { id: 'APP-2400', customer: 'Sara Al-Mannai', status: 'approved' as const, activated: 'Yes' },
  { id: 'APP-2398', customer: 'Fatima Al-Thani', status: 'approved' as const, activated: 'Yes' },
  { id: 'APP-2397', customer: 'Khalid Al-Emadi', status: 'pending' as const, activated: 'No' },
];

function SchedulesPage() {
  const pending = scheduleRows.filter((r) => r.status === 'pending').length;
  const paid = scheduleRows.filter((r) => r.status === 'paid').length;
  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Payment schedules"
        subtitle="Mark paid and capture settlement references"
        actions={
          <>
            <button type="button" className="blox-btn blox-btn--secondary">
              Filter
            </button>
            <button type="button" className="blox-btn blox-btn--primary">
              Export
            </button>
          </>
        }
      />
      <div className="blox-stat-grid">
        <OpsStatCard label="Pending" value={String(pending)} />
        <OpsStatCard label="Paid (range)" value={String(paid)} />
      </div>
      <div className="blox-filter-bar">
        <input type="date" defaultValue="2026-07-01" aria-label="From" />
        <input type="date" defaultValue="2026-08-31" aria-label="To" />
        <select defaultValue="">
          <option value="">All statuses</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
        </select>
      </div>
      <OpsDataTable
        columns={['Schedule', 'Customer', 'Vehicle', 'Due', 'Amount', 'Status', '']}
        rows={scheduleRows.map((r) => [
          r.id,
          r.customer,
          r.vehicle,
          r.due,
          <span key="a" className="blox-money">
            {r.amount}
          </span>,
          <OpsStatusPill key="s" label={r.status} variant={r.status as OpsPillVariant} />,
          r.status === 'pending' ? (
            <button key="b" type="button" className="blox-btn blox-btn--primary">
              Mark paid
            </button>
          ) : (
            <button key="b" type="button" className="blox-btn blox-btn--ghost">
              View
            </button>
          ),
        ])}
      />
    </div>
  );
}

function ApplicationsPage() {
  return (
    <div className="blox-page">
      <OpsPageHeader title="Applications" subtitle="Servicing view — activate is not available here" />
      <OpsDataTable
        columns={['ID', 'Customer', 'Status', 'Activated']}
        rows={appRows.map((r) => [
          r.id,
          r.customer,
          <OpsStatusPill key="s" label={r.status} variant={r.status as OpsPillVariant} />,
          r.activated,
        ])}
      />
    </div>
  );
}

function App() {
  const init = useAuthStore((s) => s.init);
  useEffect(() => {
    void init();
  }, [init]);
  return (
    <Routes>
      <Route path="/auth/login" element={<LoginPage portalLabel="Blox Finance" homePath="/" />} />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="finance_officer" reasonParam="not_finance">
            <BloxShell title="Finance" nav={nav}>
              <Routes>
                <Route path="/" element={<SchedulesPage />} />
                <Route path="/applications" element={<ApplicationsPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={bloxThemeWithBrand}>
        <CssBaseline />
        <BrowserRouter>
          <ScrollToTop />
          <App />
        </BrowserRouter>
      </ThemeProvider>
    </QueryClientProvider>
  </StrictMode>,
);
