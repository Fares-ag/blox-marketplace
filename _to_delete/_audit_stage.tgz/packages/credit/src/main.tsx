import { StrictMode, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes, Link, useParams } from 'react-router-dom';
import { QueryClient, QueryClientProvider, useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ThemeProvider, CssBaseline } from '@mui/material';
import {
  AuthGuard,
  LoginPage,
  BloxShell,
  bloxThemeWithBrand,
  useAuthStore,
  apiFetch,
  getApiBase,
  OpsPageHeader,
  OpsStatusPill,
  OpsEmptyState,
  OpsPanel,
  OpsDataTable,
  ScrollToTop,
  type BloxNavItem,
  type OpsPillVariant,
} from '@drivemarket/shared';

const queryClient = new QueryClient();
const nav: BloxNavItem[] = [
  { to: '/', label: 'Queue', icon: 'queue' },
  { to: '/applications', label: 'Applications', icon: 'apps' },
];

function statusVariant(status: string): OpsPillVariant {
  if (status === 'approved' || status === 'activated' || status === 'active') return 'approved';
  if (status === 'rejected') return 'rejected';
  if (status === 'resubmission_required') return 'pending';
  return 'pending';
}

function Queue() {
  const { data, error } = useQuery({
    queryKey: ['ops-apps'],
    queryFn: () =>
      apiFetch<
        Array<{
          id: string;
          status: string;
          customer: { name: string; email: string };
          product: { make: string; model: string };
          company: { name: string };
        }>
      >('/api/ops/applications'),
  });
  return (
    <div className="blox-page">
      <OpsPageHeader title="Credit queue" subtitle="Applications awaiting underwriting review" />
      {error && <p style={{ color: 'var(--blox-danger)' }}>{(error as Error).message}</p>}
      <OpsDataTable
        columns={['Vehicle', 'Customer', 'Dealer', 'Status']}
        empty={<OpsEmptyState title="Queue clear" body="No applications waiting for review." />}
        rows={(data ?? []).map((a) => [
          <Link key="v" to={`/applications/${a.id}`}>
            {a.product.make} {a.product.model}
          </Link>,
          a.customer.name,
          a.company.name,
          <OpsStatusPill key="s" label={a.status} variant={statusVariant(a.status)} />,
        ])}
      />
    </div>
  );
}

function Detail() {
  const { id } = useParams();
  const qc = useQueryClient();
  const [reason, setReason] = useState('');
  const { data } = useQuery({
    queryKey: ['app', id],
    queryFn: () =>
      apiFetch<{
        id: string;
        status: string;
        customerEmail?: string;
        customerSnapshot?: Record<string, unknown>;
        product?: { make?: string; model?: string; modelYear?: number };
        company?: { name?: string };
        pricingSnapshot?: Record<string, unknown>;
        resubmissionComment?: string | null;
        rejectionReason?: string | null;
        financePartner?: { id: string; code: string; name: string; crmAdapter: string } | null;
        zohoLeadId?: string | null;
        zohoSyncedAt?: string | null;
        zohoSyncError?: string | null;
        leadSource?: string | null;
        documents?: Array<{ id: string; category: string; mimeType?: string | null; createdAt: string }>;
      }>(`/api/applications/${id}`),
    enabled: !!id,
  });
  const syncZoho = useMutation({
    mutationFn: () =>
      apiFetch<{ zohoLeadId: string | null; error?: string }>(
        `/api/ops/applications/${id}/sync-zoho`,
        { method: 'POST', body: '{}' },
      ),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['app', id] });
    },
  });
  const transition = useMutation({
    mutationFn: (payload: { toStatus: string; reason?: string }) =>
      apiFetch(`/api/ops/applications/${id}/transition`, {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['app', id] });
      void qc.invalidateQueries({ queryKey: ['ops-apps'] });
    },
  });

  const approveContract = useMutation({
    mutationFn: () =>
      apiFetch(`/api/ops/applications/${id}/approve-contract`, { method: 'POST' }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['app', id] });
      void qc.invalidateQueries({ queryKey: ['ops-apps'] });
    },
  });

  const activate = useMutation({
    mutationFn: () => apiFetch(`/api/ops/applications/${id}/activate`, { method: 'POST', body: '{}' }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['app', id] });
      void qc.invalidateQueries({ queryKey: ['ops-apps'] });
    },
  });

  const snap = data?.customerSnapshot ?? {};
  const pricing = data?.pricingSnapshot ?? {};

  return (
    <div className="blox-page">
      <OpsPageHeader
        title="Application review"
        subtitle="Review details and transition underwriting status"
        actions={
          <Link className="blox-btn blox-btn--ghost" to="/">
            Back to queue
          </Link>
        }
      />
      <div className="blox-section-grid blox-section-grid--2">
        <OpsPanel title="Applicant">
          <div style={{ display: 'grid', gap: 10, fontSize: '0.8125rem' }}>
            <div>
              <p className="blox-stat-card__label">Name</p>
              <p style={{ margin: 0, fontWeight: 600 }}>{String(snap.full_name ?? '—')}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Email</p>
              <p style={{ margin: 0 }}>{data?.customerEmail ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Phone</p>
              <p style={{ margin: 0 }}>{String(snap.phone ?? '—')}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">QID</p>
              <p style={{ margin: 0 }}>{String(snap.qid ?? '—')}</p>
            </div>
          </div>
        </OpsPanel>
        <OpsPanel title="Vehicle & pricing">
          <div style={{ display: 'grid', gap: 10, fontSize: '0.8125rem' }}>
            <div>
              <p className="blox-stat-card__label">Vehicle</p>
              <p style={{ margin: 0, fontWeight: 600 }}>
                {data?.product?.make} {data?.product?.model} {data?.product?.modelYear ?? ''}
              </p>
            </div>
            <div>
              <p className="blox-stat-card__label">Dealer</p>
              <p style={{ margin: 0 }}>{data?.company?.name ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Finance partner</p>
              <p style={{ margin: 0 }}>{data?.financePartner?.name ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Lead source</p>
              <p style={{ margin: 0 }}>{data?.leadSource ?? '—'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Status</p>
              {data?.status && <OpsStatusPill label={data.status} variant={statusVariant(data.status)} />}
            </div>
            <div>
              <p className="blox-stat-card__label">List / financed</p>
              <p style={{ margin: 0 }} className="blox-money">
                {pricing.list_price != null ? `QAR ${Number(pricing.list_price).toLocaleString()}` : '—'}
                {pricing.monthly != null ? ` · ~QAR ${Number(pricing.monthly).toLocaleString()}/mo` : ''}
              </p>
            </div>
          </div>
        </OpsPanel>
      </div>
      {(data?.resubmissionComment || data?.rejectionReason) && (
        <OpsPanel title="Customer message">
          <p style={{ margin: 0, fontSize: '0.8125rem' }}>
            {data.resubmissionComment ?? data.rejectionReason}
          </p>
        </OpsPanel>
      )}
      <OpsPanel title="KYC documents">
        {(data?.documents?.length ?? 0) === 0 ? (
          <OpsEmptyState title="No documents" body="The customer has not uploaded KYC files yet." />
        ) : (
          <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 8 }}>
            {data!.documents!.map((doc) => (
              <li key={doc.id} className="blox-kyc-row">
                <span>{doc.category.replace('_', ' ')}</span>
                <a
                  href={`${getApiBase()}/api/applications/${data!.id}/documents/${doc.id}/file`}
                  target="_blank"
                  rel="noreferrer"
                  className="blox-btn blox-btn--ghost"
                  style={{ padding: '4px 10px', fontSize: '0.75rem' }}
                >
                  View file
                </a>
              </li>
            ))}
          </ul>
        )}
      </OpsPanel>
      {data?.financePartner?.crmAdapter === 'zoho' && (
        <OpsPanel title="Zoho CRM">
          <div style={{ display: 'grid', gap: 10, fontSize: '0.8125rem' }}>
            <div>
              <p className="blox-stat-card__label">Zoho lead ID</p>
              <p style={{ margin: 0, fontFamily: 'monospace' }}>{data.zohoLeadId ?? 'Not synced yet'}</p>
            </div>
            <div>
              <p className="blox-stat-card__label">Last synced</p>
              <p style={{ margin: 0 }}>
                {data.zohoSyncedAt ? new Date(data.zohoSyncedAt).toLocaleString() : '—'}
              </p>
            </div>
            {data.zohoSyncError && (
              <p style={{ margin: 0, color: 'var(--blox-danger)' }}>{data.zohoSyncError}</p>
            )}
            <button
              type="button"
              className="blox-btn blox-btn--secondary"
              style={{ width: 'fit-content' }}
              disabled={syncZoho.isPending}
              onClick={() => syncZoho.mutate()}
            >
              {syncZoho.isPending ? 'Syncing…' : 'Resync to Zoho'}
            </button>
          </div>
        </OpsPanel>
      )}
      <OpsPanel title="Decision">
        <label style={{ display: 'grid', gap: 6, fontSize: '0.8125rem', fontWeight: 600, maxWidth: 480 }}>
          Reason
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Required for reject / resubmission" />
        </label>
        <div className="blox-action-bar" style={{ marginTop: 14, padding: 0, border: 'none', background: 'transparent', flexWrap: 'wrap' }}>
          {data?.status === 'under_review' && (
            <button
              type="button"
              className="blox-btn blox-btn--primary"
              onClick={() => approveContract.mutate()}
              disabled={approveContract.isPending}
            >
              Approve &amp; send contract
            </button>
          )}
          {data?.status === 'contracts_submitted' && (
            <button
              type="button"
              className="blox-btn blox-btn--primary"
              onClick={() => transition.mutate({ toStatus: 'contract_under_review' })}
              disabled={transition.isPending}
            >
              Start contract review
            </button>
          )}
          {data?.status === 'contract_under_review' && (
            <button
              type="button"
              className="blox-btn blox-btn--primary"
              onClick={() => transition.mutate({ toStatus: 'pending_finance_activation' })}
              disabled={transition.isPending}
            >
              Approve contract
            </button>
          )}
          {data?.status === 'pending_finance_activation' && (
            <button
              type="button"
              className="blox-btn blox-btn--primary"
              onClick={() => activate.mutate()}
              disabled={activate.isPending}
            >
              Activate financing
            </button>
          )}
          {(data?.status === 'under_review' || data?.status === 'resubmission_required') && (
            <>
              <button
                type="button"
                className="blox-btn blox-btn--secondary"
                onClick={() => transition.mutate({ toStatus: 'resubmission_required', reason })}
                disabled={transition.isPending}
              >
                Request resubmission
              </button>
              <button
                type="button"
                className="blox-btn blox-btn--danger"
                onClick={() => transition.mutate({ toStatus: 'rejected', reason })}
                disabled={transition.isPending}
              >
                Reject
              </button>
            </>
          )}
        </div>
      </OpsPanel>
    </div>
  );
}

function App() {
  const init = useAuthStore((s) => s.init);
  useEffect(() => {
    void init();
  }, [init]);
  return (
    <Routes>
      <Route path="/auth/login" element={<LoginPage portalLabel="Blox Credit" homePath="/" />} />
      <Route
        path="/*"
        element={
          <AuthGuard allowedRole="credit_officer" reasonParam="not_credit">
            <BloxShell title="Credit" nav={nav}>
              <Routes>
                <Route path="/" element={<Queue />} />
                <Route path="/applications" element={<Queue />} />
                <Route path="/applications/:id" element={<Detail />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BloxShell>
          </AuthGuard>
        }
      />
    </Routes>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={bloxThemeWithBrand}>
        <CssBaseline />
        <BrowserRouter>
          <ScrollToTop />
          <App />
        </BrowserRouter>
      </ThemeProvider>
    </QueryClientProvider>
  </StrictMode>,
);
