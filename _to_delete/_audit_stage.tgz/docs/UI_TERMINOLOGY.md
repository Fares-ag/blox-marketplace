# Blox UI Terminology — Marketplace Reference

Internal working reference aligned with the **"Own It, Don't Owe It"** UI Terminology Brief.

## Positioning

Blox is **not** positioned as savings vs banks. Customer copy should create **desirability and emotional ownership** — the feeling of running your own business and being in control. The vehicle is an asset you build your life or livelihood on.

| Avoid (bank / debt voice) | Use (ownership / builder voice) |
|---|---|
| Loan, financing amount | Ownership plan, co-ownership agreement |
| Monthly installment / repayment | Capital contribution / ownership contribution |
| Lender | Co-owner, funding partner |
| Balance owed | Partner's remaining stake |
| Your debt / liability | Your ownership / your equity |
| Approval / application approved | Partnership confirmed / terms agreed |
| Late payment / overdue / penalty | Contribution due / catch up your share |
| Interest / rate | Do not use |
| Repayment schedule | Ownership timeline / buyout schedule |
| Default / delinquent | Behind on contributions |

### Legal cautions

- Never: "investment", "returns", "appreciating asset"
- "Equity" OK for ownership-share visualization only — not startup cap-table language ("shares", "stock", "valuation")

### Voice checklist

Before shipping copy, ask:

1. Does this sound like a **bank evaluating a borrower**?
2. Does it lead with **cost/rate** instead of **control/progress**?
3. Does it use **deadlines to fear** instead of **milestones to celebrate**?

If yes to 1–2, rewrite. If yes to 3 on on-track states, soften.

---

## Implementation status

| Screen | i18n updated | Hardcoded strings | Ownership UX |
|---|---|---|---|
| Home | Yes | — | — |
| Vehicles browse | Yes | — | — |
| Vehicle detail / CTA | Yes | — | — |
| Apply flow | Yes | AppRoutes form labels | — |
| Quote page | Yes | — | — |
| Help FAQ | Yes | — | — |
| Auth (login/signup) | Yes | LoginPage tagline | — |
| Customer dashboard | Yes | — | OwnershipProgress |
| Application detail | Yes | — | Ownership timeline |
| Compare | Yes | — | — |

**Phase 2 (Creative):**

| Ritual | Marketplace | BadrGo |
|---|---|---|
| Hygiene (no bank echo mid-journey) | Auth i18n wired (`signInLead` / `signUpLead`) | Nav, plans, payments, CTAs, support |
| Stake Preview (vehicle detail) | `StakePreview` in CTA panel | Calculator stake preview block |
| Milestone Voice | i18n badges in `OwnershipProgress` | Same keys in shared i18n |
| Empty as invitation | `application.empty`, `dashboard.noAppsBody` | Plans list empty state |
| Recovery path | `OwnershipProgress` contribute + timeline CTAs | Dashboard `OwnershipProgress` |

**Out of scope:** ops portals, API field names, contract PDF legal text.

---

## Phase 2 milestone names (EN)

| System | Brand name |
|---|---|
| `first_payment` | Stake started |
| 25% | Quarter yours |
| 50% | Halfway yours |
| 75% | Almost there |
| 100% | Fully yours |

Stake preview keys: `stakePreview.voice`, `afterInitial`, `percentYours`, `fullyYoursByMonth`  
Recovery keys: `ownership.behind`, `recoveryContribute`, `recoveryViewTimeline`

---

## Key string mapping (EN)

| Key | Before | After | Tone |
|---|---|---|---|
| `home.headline` | The market at your home | Your car. Your stake. Your move. | Control |
| `home.support` | …finance in one place | …start owning on your terms | Partnership |
| `home.howItWorks` | How financing works | How ownership works | Education |
| `detail.apply` | Apply for financing | Start your ownership plan | Action |
| `detail.estMonthly` | Est. monthly | Est. contribution | Progress |
| `detail.pendingFinancing` | Pending financing | Building your stake | Progress |
| `application.contractTitle` | Financing contract | Co-ownership agreement | Partnership |
| `application.scheduleTitle` | Payment schedule | Your ownership timeline | Progress |
| `application.status.rejected` | Not approved | Terms not confirmed | Neutral |
| `dashboard.activeFinancing` | Active financing in progress | Building toward fully yours | Progress |
| `meta.homeTitle` | Vehicle financing marketplace | Own your vehicle, your way | Brand |

Full EN/AR strings live in `packages/shared/src/i18n/locales.ts`.

---

## Banned terms (marketplace grep target)

`loan`, `financing`, `installment`, `repayment`, `approval`, `interest`, `rate`, `balance owed`, `lender`, `debt`, `delinquent`, `default`, `underwriting`, `credit review` (as primary customer-facing labels)

Note: internal code may retain `financeEligible`, `monthly`, `estimateMonthlyPayment` — UI labels only change.
