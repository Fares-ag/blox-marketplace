-- Finance partners + Zoho CRM sync fields on applications

CREATE TYPE "CrmAdapter" AS ENUM ('none', 'zoho');

CREATE TABLE "finance_partners" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "crmAdapter" "CrmAdapter" NOT NULL DEFAULT 'none',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "finance_partners_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "finance_partners_code_key" ON "finance_partners"("code");

ALTER TABLE "offers" ADD COLUMN "financePartnerId" TEXT;
ALTER TABLE "offers" ADD CONSTRAINT "offers_financePartnerId_fkey"
  FOREIGN KEY ("financePartnerId") REFERENCES "finance_partners"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "applications" ADD COLUMN "financePartnerId" TEXT;
ALTER TABLE "applications" ADD COLUMN "leadSource" TEXT;
ALTER TABLE "applications" ADD COLUMN "zohoLeadId" TEXT;
ALTER TABLE "applications" ADD COLUMN "zohoSyncedAt" TIMESTAMP(3);
ALTER TABLE "applications" ADD COLUMN "zohoSyncError" TEXT;

ALTER TABLE "applications" ADD CONSTRAINT "applications_financePartnerId_fkey"
  FOREIGN KEY ("financePartnerId") REFERENCES "finance_partners"("id") ON DELETE SET NULL ON UPDATE CASCADE;

INSERT INTO "finance_partners" ("id", "code", "name", "active", "crmAdapter", "createdAt", "updatedAt")
VALUES
  ('seed-al-jazeera', 'al_jazeera', 'Al Jazeera Finance', true, 'zoho', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('seed-blox-finance', 'blox_finance', 'Blox Finance', true, 'none', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;

INSERT INTO "offers" (
  "id", "name", "annualRentRate", "tenureOptions", "isDefault", "status", "minDownPaymentPct",
  "financePartnerId", "createdAt", "updatedAt"
)
VALUES (
  'seed-al-jazeera-offer',
  'Al Jazeera Finance Plan',
  11.5,
  '[12,24,36,48,60]'::jsonb,
  false,
  'active',
  10,
  'seed-al-jazeera',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
)
ON CONFLICT ("id") DO UPDATE SET
  "financePartnerId" = EXCLUDED."financePartnerId",
  "annualRentRate" = EXCLUDED."annualRentRate",
  "name" = EXCLUDED."name";
